@ParametersAreNonnullByDefault @MethodsReturnNonnullByDefault
package com.simibubi.create.content.contraptions.actors.flwdata;

import javax.annotation.ParametersAreNonnullByDefault;
