@ParametersAreNonnullByDefault @MethodsReturnNonnullByDefault
package com.jozufozu.flywheel.backend.instancing.batching;

import javax.annotation.ParametersAreNonnullByDefault;
