@ParametersAreNonnullByDefault @MethodsReturnNonnullByDefault
package com.jozufozu.flywheel.core.virtual;

import javax.annotation.ParametersAreNonnullByDefault;
