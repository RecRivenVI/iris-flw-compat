package com.jozufozu.flywheel.mixin;

import net.minecraft.client.Minecraft;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(Minecraft.class)
public interface PausedPartialTickAccessor {
	@Accessor("pausePartialTick")
	float flywheel$getPausePartialTick();
}
