package com.jozufozu.flywheel.mixin;

import java.util.SortedSet;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.server.level.BlockDestructionProgress;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import it.unimi.dsi.fastutil.longs.Long2ObjectMap;

@Mixin(LevelRenderer.class)
public interface LevelRendererAccessor {
	@Accessor("destructionProgress")
	Long2ObjectMap<SortedSet<BlockDestructionProgress>> flywheel$getDestructionProgress();
}
