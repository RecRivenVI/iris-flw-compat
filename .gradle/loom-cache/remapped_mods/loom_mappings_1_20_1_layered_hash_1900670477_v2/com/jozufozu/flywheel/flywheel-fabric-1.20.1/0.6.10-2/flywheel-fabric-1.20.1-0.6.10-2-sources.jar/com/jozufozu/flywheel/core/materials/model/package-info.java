@ParametersAreNonnullByDefault @MethodsReturnNonnullByDefault
package com.jozufozu.flywheel.core.materials.model;

import javax.annotation.ParametersAreNonnullByDefault;
