@ParametersAreNonnullByDefault @MethodsReturnNonnullByDefault
package com.jozufozu.flywheel.api.vertex;

import javax.annotation.ParametersAreNonnullByDefault;
