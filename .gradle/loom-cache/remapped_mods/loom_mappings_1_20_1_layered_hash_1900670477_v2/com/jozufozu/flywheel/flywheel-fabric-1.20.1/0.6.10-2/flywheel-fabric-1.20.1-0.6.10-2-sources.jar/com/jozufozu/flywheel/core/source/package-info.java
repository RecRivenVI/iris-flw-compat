@ParametersAreNonnullByDefault @MethodsReturnNonnullByDefault
package com.jozufozu.flywheel.core.source;

import javax.annotation.ParametersAreNonnullByDefault;
