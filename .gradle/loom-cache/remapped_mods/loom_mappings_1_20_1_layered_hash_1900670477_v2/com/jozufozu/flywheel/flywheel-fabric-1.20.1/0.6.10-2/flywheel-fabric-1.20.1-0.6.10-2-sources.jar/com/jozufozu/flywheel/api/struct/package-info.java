@ParametersAreNonnullByDefault @MethodsReturnNonnullByDefault
package com.jozufozu.flywheel.api.struct;

import javax.annotation.ParametersAreNonnullByDefault;
