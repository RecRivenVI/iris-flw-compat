@ParametersAreNonnullByDefault @MethodsReturnNonnullByDefault
package com.jozufozu.flywheel.core.hardcoded;

import javax.annotation.ParametersAreNonnullByDefault;
