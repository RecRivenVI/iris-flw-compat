package io.github.fabricators_of_create.porting_lib.mixin.common;

import io.github.fabricators_of_create.porting_lib.extensions.extensions.IShearable;
import net.minecraft.world.level.block.SeagrassBlock;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(SeagrassBlock.class)
public abstract class SeagrassBlockMixin implements IShearable {
}
