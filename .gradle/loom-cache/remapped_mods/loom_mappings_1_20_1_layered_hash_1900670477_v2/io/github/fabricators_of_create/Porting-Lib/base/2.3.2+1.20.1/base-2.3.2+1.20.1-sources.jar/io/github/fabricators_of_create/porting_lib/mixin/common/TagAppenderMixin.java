package io.github.fabricators_of_create.porting_lib.mixin.common;

import class_5124;
import io.github.fabricators_of_create.porting_lib.extensions.extensions.TagAppenderExtensions;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricTagProvider.FabricTagBuilder;
import net.minecraft.data.tags.TagsProvider;
import net.minecraft.tags.TagKey;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(TagsProvider.TagAppender.class)
public abstract class TagAppenderMixin<T> implements TagAppenderExtensions {
	@Shadow
	public abstract class_5124<T> addTag(TagKey<T> tag);

	// generics are a mess
	@SuppressWarnings({"unchecked", "ConstantConditions", "rawtypes"})
	@Override
	public <E> class_5124<E> addTags(TagKey<E>... values) {
		if ((Object) this instanceof FabricTagBuilder fabricTagBuilder) {
			for (TagKey<E> value : values) {
				fabricTagBuilder.forceAddTag(value);
			}
		} else {
			for (TagKey<E> value : values) {
				addTag((TagKey) value);
			}
		}
		return (class_5124<E>) (Object) this;
	}
}
