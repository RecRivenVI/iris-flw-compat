package io.github.fabricators_of_create.porting_lib.mixin.accessors.common.accessor;

import net.minecraft.util.random.SimpleWeightedRandomList;
import net.minecraft.world.level.BaseSpawner;
import net.minecraft.world.level.SpawnData;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(BaseSpawner.class)
public interface BaseSpawnerAccessor {
	@Accessor("spawnPotentials")
	SimpleWeightedRandomList<SpawnData> port_lib$getSpawnPotentials();

	@Accessor("nextSpawnData")
	SpawnData port_lib$getNextSpawnData();
}
