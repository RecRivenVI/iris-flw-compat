package io.github.fabricators_of_create.porting_lib.mixin.accessors.common.accessor;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.level.block.entity.BlockEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(BlockEntity.class)
public interface BlockEntityAccessor {
	@Invoker("saveMetadata")
	void port_lib$saveMetadata(CompoundTag compoundTag);
}
