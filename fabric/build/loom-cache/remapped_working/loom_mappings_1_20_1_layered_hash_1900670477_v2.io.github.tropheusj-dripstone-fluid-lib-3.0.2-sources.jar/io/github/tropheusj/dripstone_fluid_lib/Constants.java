package io.github.tropheusj.dripstone_fluid_lib;

import com.google.common.collect.ImmutableList;
import org.jetbrains.annotations.ApiStatus.Internal;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import net.minecraft.resources.ResourceLocation;

public class Constants {
	public static final List<ResourceLocation> DRIP_HANG = ImmutableList.of(new ResourceLocation("minecraft", "drip_hang"));
	public static final List<ResourceLocation> DRIP_FALL = ImmutableList.of(new ResourceLocation("minecraft", "drip_fall"));
	public static final List<ResourceLocation> SPLASH = ImmutableList.of(
			new ResourceLocation("dripstone_fluid_lib", "splash_0"),
			new ResourceLocation("dripstone_fluid_lib", "splash_1"),
			new ResourceLocation("dripstone_fluid_lib", "splash_2"),
			new ResourceLocation("dripstone_fluid_lib", "splash_3")
	);

	public static final Map<DripstoneInteractingFluid, ParticleTypeSet> FLUIDS_TO_PARTICLES = new HashMap<>();
	@Internal
	public static final Set<DripstoneInteractingFluid> TO_REGISTER = new HashSet<>();
}
