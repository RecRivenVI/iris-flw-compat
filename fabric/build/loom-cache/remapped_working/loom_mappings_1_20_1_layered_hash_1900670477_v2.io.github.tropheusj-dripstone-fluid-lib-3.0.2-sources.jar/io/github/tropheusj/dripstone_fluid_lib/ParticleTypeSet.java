package io.github.tropheusj.dripstone_fluid_lib;

import net.minecraft.core.particles.SimpleParticleType;

public record ParticleTypeSet(SimpleParticleType hang, SimpleParticleType fall, SimpleParticleType splash) {
}
