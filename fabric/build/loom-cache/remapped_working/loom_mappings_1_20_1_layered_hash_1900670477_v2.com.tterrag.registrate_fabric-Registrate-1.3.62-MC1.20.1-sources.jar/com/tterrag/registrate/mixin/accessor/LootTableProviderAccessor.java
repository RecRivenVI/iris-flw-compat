package com.tterrag.registrate.mixin.accessor;

import java.util.List;
import net.minecraft.data.loot.LootTableProvider;
import net.minecraft.data.loot.LootTableProvider.SubProviderEntry;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(LootTableProvider.class)
public interface LootTableProviderAccessor {
    @Mutable
    @Accessor
    void setSubProviders(List<SubProviderEntry> entries);
}
