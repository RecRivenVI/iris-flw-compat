package io.github.tropheusj.milk.mixin;

import java.util.List;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.alchemy.PotionBrewing;
import net.minecraft.world.item.crafting.Ingredient;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import io.github.tropheusj.milk.Milk;

@Mixin(PotionBrewing.class)
public abstract class BrewingRecipeRegistryMixin {
	@Shadow
	@Final
	private static List<Ingredient> POTION_TYPES;

	@Shadow
	@Final
	private static List<PotionBrewing.Mix<Item>> ITEM_RECIPES;

	@Inject(at = @At("HEAD"), method = "registerPotionType", cancellable = true)
	private static void milk$registerPotionType(Item item, CallbackInfo ci) {
		if (Milk.isMilkBottle(item)) {
			POTION_TYPES.add(Ingredient.of(item));
			ci.cancel();
		}
	}

	@Inject(at = @At("HEAD"), method = "registerItemRecipe", cancellable = true)
	private static void milk$registerItemRecipe(Item input, Item ingredient, Item output, CallbackInfo ci) {
		if (Milk.isMilkBottle(input) && Milk.isMilkBottle(output)) {
			ITEM_RECIPES.add(new PotionBrewing.Mix<>(input, class_1856.method_8091(ingredient), output));
			ci.cancel();
		}
	}
}
