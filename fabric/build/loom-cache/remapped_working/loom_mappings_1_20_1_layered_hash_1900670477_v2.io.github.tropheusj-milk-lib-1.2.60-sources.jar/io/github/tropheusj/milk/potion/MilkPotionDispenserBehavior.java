package io.github.tropheusj.milk.potion;

import io.github.tropheusj.milk.potion.bottle.PotionItemEntityExtensions;
import net.minecraft.Util;
import net.minecraft.core.BlockSource;
import net.minecraft.core.Position;
import net.minecraft.core.dispenser.AbstractProjectileDispenseBehavior;
import net.minecraft.core.dispenser.DispenseItemBehavior;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.entity.projectile.ThrownPotion;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

public enum MilkPotionDispenserBehavior implements DispenseItemBehavior {
	INSTANCE;

	@Override
	public ItemStack dispense(BlockSource blockPointer, ItemStack itemStack) {
		return (new AbstractProjectileDispenseBehavior() {
			@Override
			protected Projectile getProjectile(Level world, Position position, ItemStack stack) {
				return Util.make(new ThrownPotion(world, position.x(), position.y(), position.z()), entity -> {
					entity.setItem(stack);
					((PotionItemEntityExtensions) entity).setMilk(true);
				});
			}

			@Override
			protected float getUncertainty() {
				return super.getUncertainty() * 0.5F;
			}

			@Override
			protected float getPower() {
				return super.getPower() * 1.25F;
			}
		}).dispense(blockPointer, itemStack);
	}
}
