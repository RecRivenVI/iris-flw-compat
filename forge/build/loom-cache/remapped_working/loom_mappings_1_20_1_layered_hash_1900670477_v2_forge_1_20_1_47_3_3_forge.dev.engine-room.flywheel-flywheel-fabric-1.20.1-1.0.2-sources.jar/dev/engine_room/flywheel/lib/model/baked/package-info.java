@ParametersAreNonnullByDefault
@FieldsAreNonnullByDefault
@MethodsReturnNonnullByDefault
package dev.engine_room.flywheel.lib.model.baked;

import javax.annotation.ParametersAreNonnullByDefault;
