package dev.engine_room.flywheel.impl.visualization.storage;

import dev.engine_room.flywheel.api.visual.EntityVisual;
import dev.engine_room.flywheel.api.visualization.EntityVisualizer;
import dev.engine_room.flywheel.api.visualization.VisualizationContext;
import dev.engine_room.flywheel.lib.visualization.VisualizationHelper;
import net.minecraft.class_1297;
import net.minecraft.class_1937;

public class EntityStorage extends Storage<class_1297> {
	@Override
	protected EntityVisual<?> createRaw(VisualizationContext context, class_1297 obj, float partialTick) {
		var visualizer = VisualizationHelper.getVisualizer(obj);
		if (visualizer == null) {
			return null;
		}

		return visualizer.createVisual(context, obj, partialTick);
	}

	@Override
	public boolean willAccept(class_1297 entity) {
		if (!entity.method_5805()) {
			return false;
		}

		if (!VisualizationHelper.canVisualize(entity)) {
			return false;
		}

		class_1937 level = entity.method_37908();
		return level != null;
	}
}
