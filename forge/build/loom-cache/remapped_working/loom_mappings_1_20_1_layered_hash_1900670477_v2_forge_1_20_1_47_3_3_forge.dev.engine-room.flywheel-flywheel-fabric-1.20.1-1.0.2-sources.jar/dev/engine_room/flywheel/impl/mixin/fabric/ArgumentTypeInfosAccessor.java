package dev.engine_room.flywheel.impl.mixin.fabric;

import java.util.Map;
import net.minecraft.class_2314;
import net.minecraft.class_2316;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_2316.class)
public interface ArgumentTypeInfosAccessor {
	@Accessor("BY_CLASS")
	static Map<Class<?>, class_2314<?, ?>> getBY_CLASS() {
		throw new AssertionError();
	}
}
