package dev.engine_room.flywheel.impl.extension;

import dev.engine_room.flywheel.lib.transform.PoseTransformStack;
import net.minecraft.class_4587;

/**
 * An extension interface for {@link class_4587} that provides a {@link PoseTransformStack} wrapper.
 * <br>
 * Each PoseStack lazily creates and saves a wrapper instance. This wrapper is cached and reused for all future calls.
 */
public interface PoseStackExtension {
	/**
	 * @return The {@link PoseTransformStack} wrapper for this {@link class_4587}.
	 */
	PoseTransformStack flywheel$transformStack();
}
