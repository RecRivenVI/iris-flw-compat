package dev.engine_room.flywheel.impl.mixin;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import dev.engine_room.flywheel.impl.visualization.VisualizationManagerImpl;
import net.minecraft.class_1944;
import net.minecraft.class_4076;
import net.minecraft.class_631;
import net.minecraft.class_638;

@Mixin(class_631.class)
abstract class ClientChunkCacheMixin {
	@Shadow
	@Final
	class_638 level;

	@Inject(method = "onLightUpdate", at = @At("HEAD"))
	private void flywheel$onLightUpdate(class_1944 layer, class_4076 pos, CallbackInfo ci) {
		var manager = VisualizationManagerImpl.get(level);

		if (manager != null) {
			manager.onLightUpdate(pos, layer);
		}
	}
}
