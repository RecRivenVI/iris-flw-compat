package dev.engine_room.flywheel.impl;

import org.jetbrains.annotations.UnknownNullability;

import dev.engine_room.flywheel.lib.internal.FlwLibXplat;
import dev.engine_room.flywheel.lib.model.baked.BakedModelBuilder;
import dev.engine_room.flywheel.lib.model.baked.FabricBakedModelBuilder;
import dev.engine_room.flywheel.lib.model.baked.FabricBlockModelBuilder;
import net.minecraft.class_1087;
import net.minecraft.class_1092;
import net.minecraft.class_1920;
import net.minecraft.class_2338;
import net.minecraft.class_2960;
import dev.engine_room.flywheel.lib.model.baked.BlockModelBuilder;

public class FlwLibXplatImpl implements FlwLibXplat {
	@Override
	@UnknownNullability
	public class_1087 getBakedModel(class_1092 modelManager, class_2960 location) {
		return modelManager.method_4742(location);
	}

	@Override
	public BakedModelBuilder createBakedModelBuilder(class_1087 bakedModel) {
		return new FabricBakedModelBuilder(bakedModel);
	}

	@Override
	public BlockModelBuilder createBlockModelBuilder(class_1920 level, Iterable<class_2338> positions) {
		return new FabricBlockModelBuilder(level, positions);
	}
}
