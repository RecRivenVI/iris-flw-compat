package dev.engine_room.flywheel.backend.compile;

import dev.engine_room.flywheel.backend.NoiseTextures;
import dev.engine_room.flywheel.lib.util.ResourceUtil;
import net.fabricmc.fabric.api.resource.SimpleSynchronousResourceReloadListener;
import net.minecraft.class_2960;
import net.minecraft.class_3300;

public final class FlwProgramsReloader implements SimpleSynchronousResourceReloadListener {
	public static final FlwProgramsReloader INSTANCE = new FlwProgramsReloader();

	public static final class_2960 ID = ResourceUtil.rl("programs");

	private FlwProgramsReloader() {
	}

	@Override
	public void onResourceManagerReload(class_3300 manager) {
		FlwPrograms.reload(manager);
		NoiseTextures.reload(manager);
	}

	@Override
	public class_2960 getFabricId() {
		return ID;
	}
}
