package dev.engine_room.flywheel.impl;

import java.util.List;
import net.minecraft.class_2382;
import net.minecraft.class_310;
import dev.engine_room.flywheel.api.visualization.VisualizationManager;
import dev.engine_room.flywheel.lib.memory.FlwMemoryTracker;
import dev.engine_room.flywheel.lib.util.StringUtil;

public final class FlwDebugInfo {
	private FlwDebugInfo() {
	}

	public static void addDebugInfo(class_310 minecraft, List<String> systemInfo) {
		if (minecraft.method_1555()) {
			return;
		}

		systemInfo.add("");
		systemInfo.add("Flywheel: " + FlwImplXplat.INSTANCE.getVersionStr());
		systemInfo.add("Backend: " + BackendManagerImpl.getBackendString());
		systemInfo.add("Update limiting: " + (FlwConfig.INSTANCE.limitUpdates() ? "on" : "off"));

		VisualizationManager manager = VisualizationManager.get(minecraft.field_1687);
		if (manager != null) {
			systemInfo.add("B: " + manager.blockEntities().visualCount()
					+ ", E: " + manager.entities().visualCount()
					+ ", F: " + manager.effects().visualCount());
			class_2382 renderOrigin = manager.renderOrigin();
			systemInfo.add("Origin: " + renderOrigin.method_10263() + ", " + renderOrigin.method_10264() + ", " + renderOrigin.method_10260());
		}

		systemInfo.add("Memory Usage: CPU: " + StringUtil.formatBytes(FlwMemoryTracker.getCpuMemory()) + ", GPU: " + StringUtil.formatBytes(FlwMemoryTracker.getGpuMemory()));
	}
}
