package dev.engine_room.flywheel.impl;

import org.jetbrains.annotations.Nullable;

import dev.engine_room.flywheel.api.backend.Backend;
import dev.engine_room.flywheel.api.internal.FlwApiLink;
import dev.engine_room.flywheel.api.layout.LayoutBuilder;
import dev.engine_room.flywheel.api.registry.IdRegistry;
import dev.engine_room.flywheel.api.visualization.BlockEntityVisualizer;
import dev.engine_room.flywheel.api.visualization.EntityVisualizer;
import dev.engine_room.flywheel.api.visualization.VisualizationManager;
import dev.engine_room.flywheel.impl.layout.LayoutBuilderImpl;
import dev.engine_room.flywheel.impl.registry.IdRegistryImpl;
import dev.engine_room.flywheel.impl.visualization.VisualizationManagerImpl;
import dev.engine_room.flywheel.impl.visualization.VisualizerRegistryImpl;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1936;
import net.minecraft.class_2586;
import net.minecraft.class_2591;

public class FlwApiLinkImpl implements FlwApiLink {
	@Override
	public <T> IdRegistry<T> createIdRegistry() {
		return new IdRegistryImpl<>();
	}

	@Override
	public Backend getCurrentBackend() {
		return BackendManagerImpl.currentBackend();
	}

	@Override
	public boolean isBackendOn() {
		return BackendManagerImpl.isBackendOn();
	}

	@Override
	public Backend getOffBackend() {
		return BackendManagerImpl.OFF_BACKEND;
	}

	@Override
	public Backend getDefaultBackend() {
		return BackendManagerImpl.defaultBackend();
	}

	@Override
	public LayoutBuilder createLayoutBuilder() {
		return new LayoutBuilderImpl();
	}

	@Override
	public boolean supportsVisualization(@Nullable class_1936 level) {
		return VisualizationManagerImpl.supportsVisualization(level);
	}

	@Override
	@Nullable
	public VisualizationManager getVisualizationManager(@Nullable class_1936 level) {
		return VisualizationManagerImpl.get(level);
	}

	@Override
	public VisualizationManager getVisualizationManagerOrThrow(@Nullable class_1936 level) {
		return VisualizationManagerImpl.getOrThrow(level);
	}

	@Override
	@Nullable
	public <T extends class_2586> BlockEntityVisualizer<? super T> getVisualizer(class_2591<T> type) {
		return VisualizerRegistryImpl.getVisualizer(type);
	}

	@Override
	@Nullable
	public <T extends class_1297> EntityVisualizer<? super T> getVisualizer(class_1299<T> type) {
		return VisualizerRegistryImpl.getVisualizer(type);
	}

	@Override
	public <T extends class_2586> void setVisualizer(class_2591<T> type, @Nullable BlockEntityVisualizer<? super T> visualizer) {
		VisualizerRegistryImpl.setVisualizer(type, visualizer);
	}

	@Override
	public <T extends class_1297> void setVisualizer(class_1299<T> type, @Nullable EntityVisualizer<? super T> visualizer) {
		VisualizerRegistryImpl.setVisualizer(type, visualizer);
	}
}
