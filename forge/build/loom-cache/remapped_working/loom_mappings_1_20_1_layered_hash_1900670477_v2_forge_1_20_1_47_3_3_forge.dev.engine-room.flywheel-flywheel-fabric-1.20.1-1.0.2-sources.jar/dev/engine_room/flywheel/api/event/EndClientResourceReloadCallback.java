package dev.engine_room.flywheel.api.event;

import java.util.Optional;

import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_310;
import net.minecraft.class_3300;

@FunctionalInterface
public interface EndClientResourceReloadCallback {
	Event<EndClientResourceReloadCallback> EVENT = EventFactory.createArrayBacked(EndClientResourceReloadCallback.class,
			callbacks -> (minecraft, resourceManager, initialReload, error) -> {
				for (EndClientResourceReloadCallback callback : callbacks) {
					callback.onEndClientResourceReload(minecraft, resourceManager, initialReload, error);
				}
			});

	void onEndClientResourceReload(class_310 minecraft, class_3300 resourceManager, boolean initialReload,
								   Optional<Throwable> error);
}
