package dev.engine_room.flywheel.lib.model.baked;

import java.util.function.ToIntFunction;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import org.jetbrains.annotations.Nullable;

public class FabricSinglePosVirtualBlockGetter extends SinglePosVirtualBlockGetter {
	@Nullable
	protected Object renderData;

	public FabricSinglePosVirtualBlockGetter(ToIntFunction<class_2338> blockLightFunc, ToIntFunction<class_2338> skyLightFunc) {
		super(blockLightFunc, skyLightFunc);
	}

	public static FabricSinglePosVirtualBlockGetter createFullDark() {
		return new FabricSinglePosVirtualBlockGetter(p -> 0, p -> 0);
	}

	public static FabricSinglePosVirtualBlockGetter createFullBright() {
		return new FabricSinglePosVirtualBlockGetter(p -> 15, p -> 15);
	}

	@Override
	public FabricSinglePosVirtualBlockGetter pos(class_2338 pos) {
		super.pos(pos);
		return this;
	}

	@Override
	public FabricSinglePosVirtualBlockGetter blockState(class_2680 state) {
		super.blockState(blockState);
		return this;
	}

	@Override
	public FabricSinglePosVirtualBlockGetter blockEntity(@Nullable class_2586 blockEntity) {
		super.blockEntity(blockEntity);
		return this;
	}

	public FabricSinglePosVirtualBlockGetter renderData(@Nullable Object renderData) {
		this.renderData = renderData;
		return this;
	}

	@Override
	@Nullable
	public Object getBlockEntityRenderData(class_2338 pos) {
		if (pos.equals(this.pos)) {
			return renderData != null ? renderData : super.getBlockEntityRenderData(pos);
		}

		return super.getBlockEntityRenderData(pos);
	}
}
