package dev.engine_room.flywheel.impl.mixin;

import java.util.Map;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_630;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_630.class)
public interface ModelPartAccessor {
	@Accessor("children")
	Map<String, class_630> flywheel$children();

	@Invoker("compile")
	void flywheel$compile(class_4587.class_4665 pose, class_4588 vertexConsumer, int packedLight, int packedOverlay, float red, float green, float blue, float alpha);
}
