package dev.engine_room.flywheel.impl;

import dev.engine_room.flywheel.backend.engine.uniform.DebugMode;
import net.minecraft.class_2319;
import net.minecraft.class_7485;

public class DebugModeArgument extends class_7485<DebugMode> {
	public static final DebugModeArgument INSTANCE = new DebugModeArgument();
	public static final class_2319<DebugModeArgument> INFO = class_2319.method_41999(() -> INSTANCE);

	public DebugModeArgument() {
		super(DebugMode.CODEC, DebugMode::values);
	}
}
