package dev.engine_room.flywheel.api.event;

import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_638;

@FunctionalInterface
public interface ReloadLevelRendererCallback {
	Event<ReloadLevelRendererCallback> EVENT =
			EventFactory.createArrayBacked(ReloadLevelRendererCallback.class, callbacks -> level -> {
				for (ReloadLevelRendererCallback callback : callbacks) {
					callback.onReloadLevelRenderer(level);
				}
			});

	void onReloadLevelRenderer(class_638 level);
}
