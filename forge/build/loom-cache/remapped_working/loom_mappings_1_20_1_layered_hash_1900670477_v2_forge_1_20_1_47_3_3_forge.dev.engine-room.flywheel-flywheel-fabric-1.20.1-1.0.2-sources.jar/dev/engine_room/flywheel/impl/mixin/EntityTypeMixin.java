package dev.engine_room.flywheel.impl.mixin;

import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

import dev.engine_room.flywheel.api.visualization.EntityVisualizer;
import dev.engine_room.flywheel.impl.extension.EntityTypeExtension;
import net.minecraft.class_1297;
import net.minecraft.class_1299;

@Mixin(class_1299.class)
abstract class EntityTypeMixin<T extends class_1297> implements EntityTypeExtension<T> {
	@Unique
	@Nullable
	private EntityVisualizer<? super T> flywheel$visualizer;

	@Override
	@Nullable
	public EntityVisualizer<? super T> flywheel$getVisualizer() {
		return flywheel$visualizer;
	}

	@Override
	public void flywheel$setVisualizer(@Nullable EntityVisualizer<? super T> visualizer) {
		flywheel$visualizer = visualizer;
	}
}
