package dev.engine_room.flywheel.impl;

import java.util.Deque;
import java.util.Map;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_630;
import org.slf4j.Logger;
import dev.engine_room.flywheel.impl.compat.IrisCompat;
import dev.engine_room.flywheel.impl.compat.OptifineCompat;
import dev.engine_room.flywheel.impl.extension.PoseStackExtension;
import dev.engine_room.flywheel.impl.mixin.ModelPartAccessor;
import dev.engine_room.flywheel.impl.mixin.PoseStackAccessor;
import dev.engine_room.flywheel.lib.internal.FlwLibLink;
import dev.engine_room.flywheel.lib.transform.PoseTransformStack;

public class FlwLibLinkImpl implements FlwLibLink {
	@Override
	public Logger getLogger() {
		return FlwImpl.LOGGER;
	}

	@Override
	public PoseTransformStack getPoseTransformStackOf(class_4587 stack) {
		return ((PoseStackExtension) stack).flywheel$transformStack();
	}

	@Override
	public Map<String, class_630> getModelPartChildren(class_630 part) {
		return ((ModelPartAccessor) (Object) part).flywheel$children();
	}

	@Override
	public void compileModelPart(class_630 part, class_4587.class_4665 pose, class_4588 consumer, int light, int overlay, float red, float green, float blue, float alpha) {
		((ModelPartAccessor) (Object) part).flywheel$compile(pose, consumer, light, overlay, red, green, blue, alpha);
	}

	@Override
	public Deque<class_4587.class_4665> getPoseStack(class_4587 stack) {
		return ((PoseStackAccessor) stack).flywheel$getPoseStack();
	}

	@Override
	public boolean isIrisLoaded() {
		return IrisCompat.ACTIVE;
	}

	@Override
	public boolean isOptifineInstalled() {
		return OptifineCompat.IS_INSTALLED;
	}

	@Override
	public boolean isShaderPackInUse() {
		if (IrisCompat.ACTIVE) {
			return IrisCompat.isShaderPackInUse();
		} else if (OptifineCompat.IS_INSTALLED) {
			return OptifineCompat.isShaderPackInUse();
		} else {
			return false;
		}
	}

	@Override
	public boolean isRenderingShadowPass() {
		if (IrisCompat.ACTIVE) {
			return IrisCompat.isRenderingShadowPass();
		} else if (OptifineCompat.IS_INSTALLED) {
			return OptifineCompat.isRenderingShadowPass();
		} else {
			return false;
		}
	}
}
