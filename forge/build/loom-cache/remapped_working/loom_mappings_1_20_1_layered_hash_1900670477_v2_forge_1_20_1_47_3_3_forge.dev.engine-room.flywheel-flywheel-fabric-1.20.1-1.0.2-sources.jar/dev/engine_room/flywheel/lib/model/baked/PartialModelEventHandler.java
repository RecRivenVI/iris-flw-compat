package dev.engine_room.flywheel.lib.model.baked;

import java.util.List;

import org.jetbrains.annotations.ApiStatus;

import dev.engine_room.flywheel.lib.util.ResourceUtil;
import net.fabricmc.fabric.api.resource.ResourceReloadListenerKeys;
import net.fabricmc.fabric.api.resource.SimpleSynchronousResourceReloadListener;
import net.minecraft.class_1092;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3300;

@ApiStatus.Internal
public final class PartialModelEventHandler {
	private PartialModelEventHandler() {
	}

	public static class_2960[] onRegisterAdditional() {
		return PartialModel.ALL.keySet().toArray(class_2960[]::new);
	}

	public static void onBakingCompleted(class_1092 manager) {
		PartialModel.populateOnInit = true;

		for (PartialModel partial : PartialModel.ALL.values()) {
			partial.bakedModel = manager.method_4742(partial.modelLocation());
		}
	}

	public static final class ReloadListener implements SimpleSynchronousResourceReloadListener {
		public static final ReloadListener INSTANCE = new ReloadListener();

		public static final class_2960 ID = ResourceUtil.rl("partial_models");
		public static final List<class_2960> DEPENDENCIES = List.of(ResourceReloadListenerKeys.MODELS);

		private ReloadListener() {
		}

		@Override
		public void onResourceManagerReload(class_3300 resourceManager) {
			onBakingCompleted(class_310.method_1551().method_1554());
		}

		@Override
		public class_2960 getFabricId() {
			return ID;
		}

		@Override
		public List<class_2960> getFabricDependencies() {
			return DEPENDENCIES;
		}
	}
}
