package dev.engine_room.flywheel.lib.model.baked;

import java.util.function.BiFunction;
import net.minecraft.class_1920;
import net.minecraft.class_1921;
import net.minecraft.class_2338;
import net.minecraft.class_4587;
import org.jetbrains.annotations.Nullable;
import dev.engine_room.flywheel.api.material.Material;
import dev.engine_room.flywheel.api.model.Mesh;
import dev.engine_room.flywheel.api.model.Model;
import dev.engine_room.flywheel.lib.model.ModelUtil;
import dev.engine_room.flywheel.lib.model.SimpleModel;

public final class FabricBlockModelBuilder extends BlockModelBuilder {
	public FabricBlockModelBuilder(class_1920 level, Iterable<class_2338> positions) {
		super(level, positions);
	}

	@Override
	public FabricBlockModelBuilder poseStack(@Nullable class_4587 poseStack) {
		super.poseStack(poseStack);
		return this;
	}

	@Override
	public FabricBlockModelBuilder renderFluids(boolean renderFluids) {
		super.renderFluids(renderFluids);
		return this;
	}

	@Override
	public FabricBlockModelBuilder materialFunc(@Nullable BiFunction<class_1921, Boolean, Material> materialFunc) {
		super.materialFunc(materialFunc);
		return this;
	}

	@Override
	public SimpleModel build() {
		if (materialFunc == null) {
			materialFunc = ModelUtil::getMaterial;
		}

		var builder = ChunkLayerSortedListBuilder.<Model.ConfiguredMesh>getThreadLocal();

		BakedModelBufferer.bufferBlocks(positions.iterator(), level, poseStack, renderFluids, (renderType, shaded, data) -> {
			Material material = materialFunc.apply(renderType, shaded);
			if (material != null) {
				Mesh mesh = MeshHelper.blockVerticesToMesh(data, "source=BlockModelBuilder," + "renderType=" + renderType + ",shaded=" + shaded);
				builder.add(renderType, new Model.ConfiguredMesh(material, mesh));
			}
		});

		return new SimpleModel(builder.build());
	}
}
