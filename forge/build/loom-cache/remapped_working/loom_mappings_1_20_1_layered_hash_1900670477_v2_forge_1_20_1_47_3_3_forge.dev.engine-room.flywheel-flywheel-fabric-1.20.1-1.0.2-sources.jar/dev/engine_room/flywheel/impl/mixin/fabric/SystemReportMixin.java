package dev.engine_room.flywheel.impl.mixin.fabric;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import dev.engine_room.flywheel.impl.BackendManagerImpl;
import net.minecraft.class_6396;

@Mixin(value = class_6396.class, priority = 1056)
abstract class SystemReportMixin {
	@Inject(method = "<init>", at = @At("RETURN"))
	private void flywheel$onInit(CallbackInfo ci) {
		class_6396 self = (class_6396) (Object) this;
		self.method_37123("Flywheel Backend", BackendManagerImpl::getBackendString);
	}
}
