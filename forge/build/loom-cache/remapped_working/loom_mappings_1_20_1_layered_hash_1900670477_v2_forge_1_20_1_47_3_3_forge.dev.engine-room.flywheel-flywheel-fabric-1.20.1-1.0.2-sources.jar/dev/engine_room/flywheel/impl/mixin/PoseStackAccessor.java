package dev.engine_room.flywheel.impl.mixin;

import java.util.Deque;
import net.minecraft.class_4587;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_4587.class)
public interface PoseStackAccessor {
	@Accessor("poseStack")
	Deque<class_4587.class_4665> flywheel$getPoseStack();
}
