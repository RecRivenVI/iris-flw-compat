package dev.engine_room.flywheel.impl.visualization;

import java.util.ArrayList;
import java.util.List;
import java.util.SortedSet;
import net.minecraft.class_1297;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_1944;
import net.minecraft.class_2338;
import net.minecraft.class_2382;
import net.minecraft.class_2586;
import net.minecraft.class_310;
import net.minecraft.class_3191;
import net.minecraft.class_4076;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.Nullable;
import org.joml.FrustumIntersection;
import org.joml.Matrix4f;
import BlockEntityVisual;
import RenderDispatcher;
import dev.engine_room.flywheel.api.backend.BackendManager;
import dev.engine_room.flywheel.api.backend.Engine;
import dev.engine_room.flywheel.api.backend.RenderContext;
import dev.engine_room.flywheel.api.instance.Instance;
import dev.engine_room.flywheel.api.task.Plan;
import dev.engine_room.flywheel.api.visual.DynamicVisual;
import dev.engine_room.flywheel.api.visual.Effect;
import dev.engine_room.flywheel.api.visual.TickableVisual;
import dev.engine_room.flywheel.api.visualization.VisualManager;
import dev.engine_room.flywheel.api.visualization.VisualizationContext;
import dev.engine_room.flywheel.api.visualization.VisualizationLevel;
import dev.engine_room.flywheel.api.visualization.VisualizationManager;
import dev.engine_room.flywheel.impl.FlwConfig;
import dev.engine_room.flywheel.impl.extension.LevelExtension;
import dev.engine_room.flywheel.impl.task.Flag;
import dev.engine_room.flywheel.impl.task.FlwTaskExecutor;
import dev.engine_room.flywheel.impl.task.RaisePlan;
import dev.engine_room.flywheel.impl.task.TaskExecutorImpl;
import dev.engine_room.flywheel.impl.visual.BandedPrimeLimiter;
import dev.engine_room.flywheel.impl.visual.DistanceUpdateLimiterImpl;
import dev.engine_room.flywheel.impl.visual.DynamicVisualContextImpl;
import dev.engine_room.flywheel.impl.visual.NonLimiter;
import dev.engine_room.flywheel.impl.visual.TickableVisualContextImpl;
import dev.engine_room.flywheel.impl.visualization.storage.BlockEntityStorage;
import dev.engine_room.flywheel.impl.visualization.storage.EffectStorage;
import dev.engine_room.flywheel.impl.visualization.storage.EntityStorage;
import dev.engine_room.flywheel.lib.task.IfElsePlan;
import dev.engine_room.flywheel.lib.task.MapContextPlan;
import dev.engine_room.flywheel.lib.task.NestedPlan;
import dev.engine_room.flywheel.lib.task.SimplePlan;
import dev.engine_room.flywheel.lib.util.LevelAttached;
import it.unimi.dsi.fastutil.longs.Long2ObjectMap;
import it.unimi.dsi.fastutil.longs.Long2ObjectMap.Entry;
import it.unimi.dsi.fastutil.longs.LongOpenHashSet;

/**
 * A manager class for a single level where visualization is supported.
 */
public class VisualizationManagerImpl implements VisualizationManager {
	private static final LevelAttached<VisualizationManagerImpl> MANAGERS = new LevelAttached<>(VisualizationManagerImpl::new, VisualizationManagerImpl::delete);

	private final TaskExecutorImpl taskExecutor;
	private final DistanceUpdateLimiterImpl frameLimiter;
	private final RenderDispatcherImpl renderDispatcher = new RenderDispatcherImpl();
	private final class_1936 level;

	// VisualizationManagerImpl can (and should!) be constructed off of the main thread, but it may be
	// difficult for engines to avoid OpenGL calls which would not be safe. Shove all the init logic
	// that depends on engine construction into here, and defer until we get invoked on the main thread.
	@Nullable
	private LateInit lateInit;

	private final VisualManagerImpl<class_2586, BlockEntityStorage> blockEntities;
	private final VisualManagerImpl<class_1297, EntityStorage> entities;
	private final VisualManagerImpl<Effect, EffectStorage> effects;

	private final Flag frameFlag = new Flag("frame");
	private final Flag tickFlag = new Flag("tick");

	private VisualizationManagerImpl(class_1936 level) {
		this.level = level;
		taskExecutor = FlwTaskExecutor.get();
		frameLimiter = createUpdateLimiter();

		blockEntities = new VisualManagerImpl<>(new BlockEntityStorage());
		entities = new VisualManagerImpl<>(new EntityStorage());
		effects = new VisualManagerImpl<>(new EffectStorage());

		if (level instanceof class_1937 l) {
			LevelExtension.getAllLoadedEntities(l)
					.forEach(entities::queueAdd);
		}
	}

	private class LateInit {
		private final Engine engine;

		private final Plan<RenderContext> framePlan;
		private final Plan<TickableVisual.Context> tickPlan;

		private LateInit(class_1936 level) {
			engine = BackendManager.currentBackend()
					.createEngine(level);

			var visualizationContext = engine.createVisualizationContext();

			var recreate = SimplePlan.<RenderContext>of(context -> blockEntities.getStorage()
					.recreateAll(visualizationContext, context.partialTick()), context -> entities.getStorage()
					.recreateAll(visualizationContext, context.partialTick()), context -> effects.getStorage()
					.recreateAll(visualizationContext, context.partialTick()));

			var update = MapContextPlan.map(this::createVisualFrameContext)
					.to(NestedPlan.of(blockEntities.framePlan(visualizationContext), entities.framePlan(visualizationContext), effects.framePlan(visualizationContext)));

			framePlan = IfElsePlan.on((RenderContext ctx) -> engine.updateRenderOrigin(ctx.camera()))
					.ifTrue(recreate)
					.ifFalse(update)
					.plan()
					.then(SimplePlan.of(() -> {
						if (blockEntities.areGpuLightSectionsDirty() || entities.areGpuLightSectionsDirty() || effects.areGpuLightSectionsDirty()) {
							var out = new LongOpenHashSet();
							out.addAll(blockEntities.gpuLightSections());
							out.addAll(entities.gpuLightSections());
							out.addAll(effects.gpuLightSections());
							engine.lightSections(out);
						}
					}))
					.then(engine.createFramePlan())
					.then(RaisePlan.raise(frameFlag));

			tickPlan = NestedPlan.of(blockEntities.tickPlan(visualizationContext), entities.tickPlan(visualizationContext), effects.tickPlan(visualizationContext))
					.then(RaisePlan.raise(tickFlag));
		}

		private DynamicVisual.Context createVisualFrameContext(RenderContext ctx) {
			class_2382 renderOrigin = engine.renderOrigin();
			var cameraPos = ctx.camera()
					.getPosition();

			Matrix4f viewProjection = new Matrix4f(ctx.viewProjection());
			viewProjection.translate((float) (renderOrigin.method_10263() - cameraPos.x), (float) (renderOrigin.method_10264() - cameraPos.y), (float) (renderOrigin.method_10260() - cameraPos.z));
			FrustumIntersection frustum = new FrustumIntersection(viewProjection);

			return new DynamicVisualContextImpl(ctx.camera(), frustum, ctx.partialTick(), frameLimiter);
		}
	}

	private LateInit lateInit() {
		if (lateInit == null) {
			lateInit = new LateInit(level);
		}

		return lateInit;
	}

	private DistanceUpdateLimiterImpl createUpdateLimiter() {
		if (FlwConfig.INSTANCE
				.limitUpdates()) {
			return new BandedPrimeLimiter();
		} else {
			return new NonLimiter();
		}
	}

	@Contract("null -> false")
	public static boolean supportsVisualization(@Nullable class_1936 level) {
		if (!BackendManager.isBackendOn()) {
			return false;
		}

		if (level == null) {
			return false;
		}

		if (!level.method_8608()) {
			return false;
		}

		if (level instanceof VisualizationLevel flywheelLevel && flywheelLevel.supportsVisualization()) {
			return true;
		}

		return level == class_310.method_1551().field_1687;
	}

	@Nullable
	public static VisualizationManagerImpl get(@Nullable class_1936 level) {
		if (!supportsVisualization(level)) {
			return null;
		}

		return MANAGERS.get(level);
	}

	public static VisualizationManagerImpl getOrThrow(@Nullable class_1936 level) {
		if (!supportsVisualization(level)) {
			throw new IllegalStateException("Cannot retrieve visualization manager when visualization is not supported by level '" + level + "'!");
		}

		return MANAGERS.get(level);
	}

	// TODO: Consider making these reset actions reuse the existing game objects instead of re-adding them
	//  potentially by keeping the same VisualizationManagerImpl and deleting the engine and visuals but not the game objects
	public static void reset(class_1936 level) {
		MANAGERS.remove(level);
	}

	public static void resetAll() {
		MANAGERS.reset();
	}

	@Override
	public class_2382 renderOrigin() {
		if (lateInit == null) {
			return class_2382.field_11176;
		} else {
			return lateInit.engine.renderOrigin();
		}
	}

	@Override
	public VisualManager<class_2586> blockEntities() {
		return blockEntities;
	}

	@Override
	public VisualManager<class_1297> entities() {
		return entities;
	}

	@Override
	public VisualManager<Effect> effects() {
		return effects;
	}

	@Override
	public dev.engine_room.flywheel.api.visualization.VisualizationManager.RenderDispatcher renderDispatcher() {
		return renderDispatcher;
	}

	/**
	 * Begin execution of the tick plan.
	 */
	public void tick() {
		// Make sure we're done with any prior frame or tick to avoid racing.
		taskExecutor.syncUntil(frameFlag::isRaised);
		frameFlag.lower();

		taskExecutor.syncUntil(tickFlag::isRaised);
		tickFlag.lower();

		lateInit().tickPlan.execute(taskExecutor, TickableVisualContextImpl.INSTANCE);
	}

	/**
	 * Begin execution of the frame plan.
	 */
	private void beginFrame(RenderContext context) {
		// Make sure we're done with the last tick.
		// Note we don't lower here because many frames may happen per tick.
		taskExecutor.syncUntil(tickFlag::isRaised);

		frameFlag.lower();

		frameLimiter.tick();

		lateInit().framePlan.execute(taskExecutor, context);
	}

	/**
	 * Draw all visuals of the given type.
	 */
	private void render(RenderContext context) {
		taskExecutor.syncUntil(frameFlag::isRaised);
		lateInit().engine.render(context);
	}

	private void renderCrumbling(RenderContext context, Long2ObjectMap<SortedSet<class_3191>> destructionProgress) {
		if (destructionProgress.isEmpty()) {
			return;
		}

		List<Engine.CrumblingBlock> crumblingBlocks = new ArrayList<>();

		for (var entry : destructionProgress.long2ObjectEntrySet()) {
			var set = entry.getValue();
			if (set == null || set.isEmpty()) {
				// Nothing to do if there's no crumbling.
				continue;
			}

			var visual = blockEntities.getStorage()
					.visualAtPos(entry.getLongKey());

			if (visual == null) {
				// The block doesn't have a visual, this is probably the common case.
				continue;
			}

			List<Instance> instances = new ArrayList<>();

			visual.collectCrumblingInstances(instance -> {
				if (instance != null) {
					instances.add(instance);
				}
			});

			if (instances.isEmpty()) {
				// The visual doesn't want to render anything crumbling.
				continue;
			}

			var maxDestruction = set.last();

			crumblingBlocks.add(new CrumblingBlockImpl(maxDestruction.method_13991(), maxDestruction.method_13988(), instances));
		}

		if (!crumblingBlocks.isEmpty()) {
			lateInit().engine.renderCrumbling(context, crumblingBlocks);
		}
	}

	public void onLightUpdate(class_4076 sectionPos, class_1944 layer) {
		lateInit().engine.onLightUpdate(sectionPos, layer);
		long longPos = sectionPos.method_18694();
		blockEntities.onLightUpdate(longPos);
		entities.onLightUpdate(longPos);
		effects.onLightUpdate(longPos);
	}

	/**
	 * Free all acquired resources and delete this manager.
	 */
	private void delete() {
		// Just finish everything. This may include the work of others but that's okay.
		taskExecutor.syncPoint();

		// Now clean up.
		blockEntities.invalidate();
		entities.invalidate();
		effects.invalidate();
		if (lateInit != null) {
			lateInit.engine.delete();
		}
	}

	private class RenderDispatcherImpl implements dev.engine_room.flywheel.api.visualization.VisualizationManager.RenderDispatcher {
		@Override
		public void onStartLevelRender(RenderContext ctx) {
			beginFrame(ctx);
		}

		@Override
		public void afterEntities(RenderContext ctx) {
			render(ctx);
		}

		@Override
		public void beforeCrumbling(RenderContext ctx, Long2ObjectMap<SortedSet<class_3191>> destructionProgress) {
			renderCrumbling(ctx, destructionProgress);
		}
	}

	private record CrumblingBlockImpl(class_2338 pos, int progress,
									  List<Instance> instances) implements dev.engine_room.flywheel.api.backend.Engine.CrumblingBlock {
	}
}
