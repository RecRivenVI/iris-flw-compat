package dev.engine_room.flywheel.lib.model.baked;

import net.minecraft.class_1921;
import net.minecraft.class_287;
import net.minecraft.class_287.class_7433;
import net.minecraft.class_290;
import net.minecraft.class_293;
import org.jetbrains.annotations.UnknownNullability;

class MeshEmitter {
	private final class_1921 renderType;
	private final class_287 bufferBuilder;

	private BakedModelBufferer.@UnknownNullability ResultConsumer resultConsumer;
	private boolean currentShade;

	MeshEmitter(class_1921 renderType) {
		this.renderType = renderType;
		this.bufferBuilder = new class_287(renderType.method_22722());
	}

	public void prepare(BakedModelBufferer.ResultConsumer resultConsumer) {
		this.resultConsumer = resultConsumer;
	}

	public void end() {
		if (bufferBuilder.method_22893()) {
			emit();
		}
		resultConsumer = null;
	}

	public class_287 getBuffer(boolean shade) {
		prepareForGeometry(shade);
		return bufferBuilder;
	}

	private void prepareForGeometry(boolean shade) {
		if (!bufferBuilder.method_22893()) {
			bufferBuilder.method_1328(class_293.class_5596.field_27382, class_290.field_1590);
		} else if (shade != currentShade) {
			emit();
			bufferBuilder.method_1328(class_293.class_5596.field_27382, class_290.field_1590);
		}

		currentShade = shade;
	}

	private void emit() {
		var renderedBuffer = bufferBuilder.method_43575();

		if (renderedBuffer != null) {
			resultConsumer.accept(renderType, currentShade, renderedBuffer);
			renderedBuffer.method_43585();
		}
	}
}
