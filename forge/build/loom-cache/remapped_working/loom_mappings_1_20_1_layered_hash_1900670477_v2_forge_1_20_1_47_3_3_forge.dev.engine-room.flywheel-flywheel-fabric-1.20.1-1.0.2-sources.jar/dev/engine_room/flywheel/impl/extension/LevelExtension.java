package dev.engine_room.flywheel.impl.extension;

import net.minecraft.class_1297;
import net.minecraft.class_1937;
import net.minecraft.class_638;

public interface LevelExtension {
	/**
	 * Get an iterator over all entities in this level.
	 *
	 * <p>
	 *     Normally, this would be accomplished by {@link class_638#method_18112}, but the output of that
	 *     method does not include entities that are rendered by Flywheel. This interface provides a workaround.
	 * </p>
	 * @return An iterator over all entities in the level, including entities that are rendered by Flywheel.
	 */
	Iterable<class_1297> flywheel$getAllLoadedEntities();

	static Iterable<class_1297> getAllLoadedEntities(class_1937 level) {
		return ((LevelExtension) level).flywheel$getAllLoadedEntities();
	}
}
