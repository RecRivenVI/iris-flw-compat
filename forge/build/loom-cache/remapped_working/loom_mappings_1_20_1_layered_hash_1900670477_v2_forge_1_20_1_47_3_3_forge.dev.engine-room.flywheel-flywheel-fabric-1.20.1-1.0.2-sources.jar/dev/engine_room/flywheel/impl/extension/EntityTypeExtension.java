package dev.engine_room.flywheel.impl.extension;

import org.jetbrains.annotations.Nullable;

import dev.engine_room.flywheel.api.visualization.EntityVisualizer;
import net.minecraft.class_1297;

public interface EntityTypeExtension<T extends class_1297> {
	@Nullable
	EntityVisualizer<? super T> flywheel$getVisualizer();

	void flywheel$setVisualizer(@Nullable EntityVisualizer<? super T> visualizer);
}
