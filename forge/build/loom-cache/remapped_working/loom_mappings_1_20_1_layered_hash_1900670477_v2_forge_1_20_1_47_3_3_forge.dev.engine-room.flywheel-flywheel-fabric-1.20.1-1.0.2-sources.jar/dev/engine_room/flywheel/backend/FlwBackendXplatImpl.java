package dev.engine_room.flywheel.backend;

import net.minecraft.class_1922;
import net.minecraft.class_2338;
import net.minecraft.class_2680;

public class FlwBackendXplatImpl implements FlwBackendXplat {
	@Override
	public int getLightEmission(class_2680 state, class_1922 level, class_2338 pos) {
		return state.method_26213();
	}
}
