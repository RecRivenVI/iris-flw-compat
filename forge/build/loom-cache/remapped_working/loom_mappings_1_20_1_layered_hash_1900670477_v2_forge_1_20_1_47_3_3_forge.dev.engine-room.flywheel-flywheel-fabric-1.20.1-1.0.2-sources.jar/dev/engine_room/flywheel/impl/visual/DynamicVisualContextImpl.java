package dev.engine_room.flywheel.impl.visual;

import org.joml.FrustumIntersection;

import dev.engine_room.flywheel.api.visual.DistanceUpdateLimiter;
import dev.engine_room.flywheel.api.visual.DynamicVisual;
import net.minecraft.class_4184;

public record DynamicVisualContextImpl(class_4184 camera, FrustumIntersection frustum, float partialTick,
									   DistanceUpdateLimiter limiter) implements DynamicVisual.Context {
}
