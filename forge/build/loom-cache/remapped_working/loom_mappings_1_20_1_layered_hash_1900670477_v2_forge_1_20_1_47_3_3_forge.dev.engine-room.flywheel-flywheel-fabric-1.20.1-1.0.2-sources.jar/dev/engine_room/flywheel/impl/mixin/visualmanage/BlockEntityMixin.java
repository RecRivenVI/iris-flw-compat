package dev.engine_room.flywheel.impl.mixin.visualmanage;

import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import dev.engine_room.flywheel.api.visualization.VisualizationManager;
import net.minecraft.class_1937;
import net.minecraft.class_2586;

@Mixin(class_2586.class)
abstract class BlockEntityMixin {
	@Shadow
	@Nullable
	protected class_1937 level;

	@Inject(method = "setRemoved()V", at = @At("TAIL"))
	private void flywheel$removeVisual(CallbackInfo ci) {
		VisualizationManager manager = VisualizationManager.get(level);
		if (manager == null) {
			return;
		}

		manager.blockEntities().queueRemove((class_2586) (Object) this);
	}
}
