package dev.engine_room.flywheel.lib.model.baked;

import java.util.function.Supplier;

import org.jetbrains.annotations.Nullable;
import org.jetbrains.annotations.UnknownNullability;
import it.unimi.dsi.fastutil.objects.Reference2ReferenceMap;
import net.fabricmc.fabric.api.renderer.v1.material.BlendMode;
import net.fabricmc.fabric.api.renderer.v1.material.RenderMaterial;
import net.fabricmc.fabric.api.renderer.v1.model.ForwardingBakedModel;
import net.fabricmc.fabric.api.renderer.v1.render.RenderContext;
import net.minecraft.class_1087;
import net.minecraft.class_1920;
import net.minecraft.class_1921;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_287;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_5819;
import net.minecraft.class_777;

class UniversalMeshEmitter implements class_4588 {
	private final Reference2ReferenceMap<class_1921, MeshEmitter> emitterMap;
	private final WrapperModel wrapperModel = new WrapperModel();

	@UnknownNullability
	private class_1921 defaultLayer;
	@UnknownNullability
	private class_287 currentDelegate;

    UniversalMeshEmitter(Reference2ReferenceMap<class_1921, MeshEmitter> emitterMap) {
		this.emitterMap = emitterMap;
    }

	public void prepare(class_1921 defaultLayer) {
		this.defaultLayer = defaultLayer;
	}

	public void clear() {
		wrapperModel.setWrapped(null);
	}

	public class_1087 wrapModel(class_1087 model) {
		wrapperModel.setWrapped(model);
		return wrapperModel;
	}

	private void prepareForGeometry(RenderMaterial material) {
		BlendMode blendMode = material.blendMode();
		class_1921 layer = blendMode == BlendMode.DEFAULT ? defaultLayer : blendMode.blockRenderLayer;
		boolean shade = !material.disableDiffuse();
		currentDelegate = emitterMap.get(layer).getBuffer(shade);
	}

	@Override
	public class_4588 method_22912(double x, double y, double z) {
		currentDelegate.method_22912(x, y, z);
		return this;
	}

	@Override
	public class_4588 method_1336(int red, int green, int blue, int alpha) {
		currentDelegate.method_1336(red, green, blue, alpha);
		return this;
	}

	@Override
	public class_4588 method_22913(float u, float v) {
		currentDelegate.method_22913(u, v);
		return this;
	}

	@Override
	public class_4588 method_22917(int u, int v) {
		currentDelegate.method_22917(u, v);
		return this;
	}

	@Override
	public class_4588 method_22921(int u, int v) {
		currentDelegate.method_22921(u, v);
		return this;
	}

	@Override
	public class_4588 method_22914(float x, float y, float z) {
		currentDelegate.method_22914(x, y, z);
		return this;
	}

	@Override
	public void method_1344() {
		currentDelegate.method_1344();
	}

	@Override
	public void method_22901(int red, int green, int blue, int alpha) {
		currentDelegate.method_22901(red, green, blue, alpha);
	}

	@Override
	public void method_35666() {
		currentDelegate.method_35666();
	}

	@Override
	public void method_23919(float x, float y, float z, float red, float green, float blue, float alpha, float u, float v, int overlay, int light, float normalX, float normalY, float normalZ) {
		currentDelegate.method_23919(x, y, z, red, green, blue, alpha, u, v, overlay, light, normalX, normalY, normalZ);
	}

	@Override
	public void method_22919(class_4587.class_4665 pose, class_777 quad, float red, float green, float blue, int light, int overlay) {
		currentDelegate.method_22919(pose, quad, red, green, blue, light, overlay);
	}

	@Override
	public void method_22920(class_4587.class_4665 pose, class_777 quad, float[] brightnesses, float red, float green, float blue, int[] lights, int overlay, boolean readExistingColor) {
		currentDelegate.method_22920(pose, quad, brightnesses, red, green, blue, lights, overlay, readExistingColor);
	}

	private class WrapperModel extends ForwardingBakedModel {
		private final RenderContext.QuadTransform quadTransform = quad -> {
			UniversalMeshEmitter.this.prepareForGeometry(quad.material());
			return true;
		};

		public void setWrapped(@Nullable class_1087 wrapped) {
			this.wrapped = wrapped;
		}

		@Override
		public boolean isVanillaAdapter() {
			return false;
		}

		@Override
		public void emitBlockQuads(class_1920 level, class_2680 state, class_2338 pos, Supplier<class_5819> randomSupplier, RenderContext context) {
			context.pushTransform(quadTransform);
			super.emitBlockQuads(level, state, pos, randomSupplier, context);
			context.popTransform();
		}
	}
}
