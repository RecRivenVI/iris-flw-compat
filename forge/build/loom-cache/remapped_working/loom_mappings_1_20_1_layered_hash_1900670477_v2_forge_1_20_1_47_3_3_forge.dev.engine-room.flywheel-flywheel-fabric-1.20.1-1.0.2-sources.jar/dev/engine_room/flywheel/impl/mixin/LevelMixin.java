package dev.engine_room.flywheel.impl.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

import dev.engine_room.flywheel.impl.extension.LevelExtension;
import net.minecraft.class_1297;
import net.minecraft.class_1937;
import net.minecraft.class_5577;

@Mixin(class_1937.class)
abstract class LevelMixin implements LevelExtension {
	@Shadow
	protected abstract class_5577<class_1297> getEntities();

	@Override
	public Iterable<class_1297> flywheel$getAllLoadedEntities() {
		return getEntities().method_31803();
	}
}
