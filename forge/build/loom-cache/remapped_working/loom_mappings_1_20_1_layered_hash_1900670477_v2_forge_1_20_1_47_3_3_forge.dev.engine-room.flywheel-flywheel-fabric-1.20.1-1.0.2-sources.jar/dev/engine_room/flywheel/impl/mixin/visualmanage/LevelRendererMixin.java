package dev.engine_room.flywheel.impl.mixin.visualmanage;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import dev.engine_room.flywheel.api.visualization.VisualManager;
import dev.engine_room.flywheel.api.visualization.VisualizationManager;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_638;
import net.minecraft.class_761;

@Mixin(class_761.class)
abstract class LevelRendererMixin {
	@Shadow
	private class_638 level;

	/**
	 * This gets called when a block is marked for rerender by vanilla.
	 */
	@Inject(method = "setBlockDirty(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/block/state/BlockState;)V", at = @At("TAIL"))
	private void flywheel$checkUpdate(class_2338 pos, class_2680 oldState, class_2680 newState, CallbackInfo ci) {
		VisualizationManager manager = VisualizationManager.get(level);
		if (manager == null) {
			return;
		}

		class_2586 blockEntity = level.method_8321(pos);
		if (blockEntity == null) {
			return;
		}

		var blockEntities = manager.blockEntities();
		if (oldState != newState) {
			blockEntities.queueRemove(blockEntity);
			blockEntities.queueAdd(blockEntity);
		} else {
			// I don't think this is possible to reach in vanilla
			blockEntities.queueUpdate(blockEntity);
		}
	}
}
