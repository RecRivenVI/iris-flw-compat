package dev.engine_room.flywheel.impl.extension;

import org.jetbrains.annotations.Nullable;

import dev.engine_room.flywheel.api.visualization.BlockEntityVisualizer;
import net.minecraft.class_2586;

public interface BlockEntityTypeExtension<T extends class_2586> {
	@Nullable
	BlockEntityVisualizer<? super T> flywheel$getVisualizer();

	void flywheel$setVisualizer(@Nullable BlockEntityVisualizer<? super T> visualizer);
}
