package dev.engine_room.flywheel.impl;

import dev.engine_room.flywheel.backend.compile.LightSmoothness;
import net.minecraft.class_2319;
import net.minecraft.class_7485;

public class LightSmoothnessArgument extends class_7485<LightSmoothness> {
	public static final LightSmoothnessArgument INSTANCE = new LightSmoothnessArgument();
	public static final class_2319<LightSmoothnessArgument> INFO = class_2319.method_41999(() -> INSTANCE);

	public LightSmoothnessArgument() {
		super(LightSmoothness.CODEC, LightSmoothness::values);
	}
}
