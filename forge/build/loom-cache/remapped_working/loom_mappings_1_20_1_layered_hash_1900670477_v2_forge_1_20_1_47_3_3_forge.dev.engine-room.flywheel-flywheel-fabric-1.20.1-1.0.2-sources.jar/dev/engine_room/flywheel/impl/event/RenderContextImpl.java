package dev.engine_room.flywheel.impl.event;

import org.joml.Matrix4f;
import org.joml.Matrix4fc;
import dev.engine_room.flywheel.api.backend.RenderContext;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4599;
import net.minecraft.class_638;
import net.minecraft.class_761;

public record RenderContextImpl(class_761 renderer, class_638 level, class_4599 buffers, class_4587 stack,
								Matrix4fc projection, Matrix4fc viewProjection, class_4184 camera,
								float partialTick) implements RenderContext {
	public static RenderContextImpl create(class_761 renderer, class_638 level, class_4599 buffers, class_4587 stack, Matrix4f projection, class_4184 camera, float partialTick) {
		Matrix4f viewProjection = new Matrix4f(projection);
		viewProjection.mul(stack.method_23760()
				.method_23761());

		return new RenderContextImpl(renderer, level, buffers, stack, projection, viewProjection, camera, partialTick);
	}
}
