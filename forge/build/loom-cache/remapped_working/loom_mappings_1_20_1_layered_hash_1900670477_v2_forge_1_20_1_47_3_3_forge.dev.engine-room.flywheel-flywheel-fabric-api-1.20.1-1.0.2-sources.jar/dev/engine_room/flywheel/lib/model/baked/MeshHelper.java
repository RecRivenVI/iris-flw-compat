package dev.engine_room.flywheel.lib.model.baked;

import java.nio.ByteBuffer;
import net.minecraft.class_287;
import org.jetbrains.annotations.Nullable;
import org.lwjgl.system.MemoryUtil;
import dev.engine_room.flywheel.lib.memory.MemoryBlock;
import dev.engine_room.flywheel.lib.model.SimpleQuadMesh;
import dev.engine_room.flywheel.lib.vertex.NoOverlayVertexView;
import dev.engine_room.flywheel.lib.vertex.VertexView;

final class MeshHelper {
	private MeshHelper() {
	}

	public static SimpleQuadMesh blockVerticesToMesh(class_287.class_7433 buffer, @Nullable String meshDescriptor) {
		class_287.class_4574 drawState = buffer.method_43583();
		int vertexCount = drawState.comp_750();
		long srcStride = drawState.comp_749().method_1362();

		VertexView vertexView = new NoOverlayVertexView();
		long dstStride = vertexView.stride();

		ByteBuffer src = buffer.method_43581();
		MemoryBlock dst = MemoryBlock.mallocTracked((long) vertexCount * dstStride);
		long srcPtr = MemoryUtil.memAddress(src);
		long dstPtr = dst.ptr();
		// The first 31 bytes of each vertex in a block vertex buffer are guaranteed to contain the same data in the
		// same order regardless of whether the format is extended by mods like Iris or OptiFine. Copy these bytes and
		// ignore the rest.
		long bytesToCopy = Math.min(dstStride, 31);

		for (int i = 0; i < vertexCount; i++) {
			// It is safe to copy bytes directly since the NoOverlayVertexView uses the same memory layout as the first
			// 31 bytes of the block vertex format, vanilla or otherwise.
			MemoryUtil.memCopy(srcPtr + srcStride * i, dstPtr + dstStride * i, bytesToCopy);
		}

		vertexView.ptr(dstPtr);
		vertexView.vertexCount(vertexCount);
		vertexView.nativeMemoryOwner(dst);

		return new SimpleQuadMesh(vertexView, meshDescriptor);
	}
}
