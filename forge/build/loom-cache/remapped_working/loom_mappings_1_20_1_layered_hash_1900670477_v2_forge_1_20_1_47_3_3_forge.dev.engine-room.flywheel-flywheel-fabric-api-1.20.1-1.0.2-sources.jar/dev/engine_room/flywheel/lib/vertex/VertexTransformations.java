package dev.engine_room.flywheel.lib.vertex;

import dev.engine_room.flywheel.api.vertex.MutableVertexList;
import net.minecraft.class_1058;

public final class VertexTransformations {
	private VertexTransformations() {
	}

	public static void retexture(MutableVertexList vertexList, int index, class_1058 sprite) {
		vertexList.u(index, sprite.method_4580(vertexList.u(index) * 16));
		vertexList.v(index, sprite.method_4570(vertexList.v(index) * 16));
	}

	public static void retexture(MutableVertexList vertexList, class_1058 sprite) {
		for (int i = 0; i < vertexList.vertexCount(); i++) {
			retexture(vertexList, i, sprite);
		}
	}
}
