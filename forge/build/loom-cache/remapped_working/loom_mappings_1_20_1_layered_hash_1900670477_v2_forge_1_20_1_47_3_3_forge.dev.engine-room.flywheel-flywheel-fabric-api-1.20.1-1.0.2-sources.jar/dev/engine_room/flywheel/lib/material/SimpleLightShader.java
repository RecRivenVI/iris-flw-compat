package dev.engine_room.flywheel.lib.material;

import dev.engine_room.flywheel.api.material.LightShader;
import net.minecraft.class_2960;

public record SimpleLightShader(@Override class_2960 source) implements LightShader {
}
