package dev.engine_room.flywheel.lib.material;

import dev.engine_room.flywheel.api.material.MaterialShaders;
import net.minecraft.class_2960;

public record SimpleMaterialShaders(class_2960 vertexSource, class_2960 fragmentSource) implements MaterialShaders {
}
