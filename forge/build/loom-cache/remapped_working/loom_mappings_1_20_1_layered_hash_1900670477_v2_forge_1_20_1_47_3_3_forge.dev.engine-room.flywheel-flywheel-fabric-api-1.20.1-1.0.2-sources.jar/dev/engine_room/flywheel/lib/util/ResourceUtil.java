package dev.engine_room.flywheel.lib.util;

import com.mojang.brigadier.StringReader;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.exceptions.SimpleCommandExceptionType;

import dev.engine_room.flywheel.api.Flywheel;
import net.minecraft.class_151;
import net.minecraft.class_2561;
import net.minecraft.class_2960;

public final class ResourceUtil {
	private static final SimpleCommandExceptionType ERROR_INVALID = new SimpleCommandExceptionType(class_2561.method_43471("argument.id.invalid"));

	private ResourceUtil() {
	}

	public static class_2960 rl(String path) {
		return new class_2960(Flywheel.ID, path);
	}

	/**
	 * Same as {@link class_2960#class_2960(String)}, but defaults to Flywheel namespace.
	 */
	public static class_2960 parseFlywheelDefault(String location) {
		String namespace = Flywheel.ID;
		String path = location;

		int i = location.indexOf(class_2960.field_33380);
		if (i >= 0) {
			path = location.substring(i + 1);
			if (i >= 1) {
				namespace = location.substring(0, i);
			}
		}

		return new class_2960(namespace, path);
	}

	/**
	 * Same as {@link class_2960#method_12835(StringReader)}, but defaults to Flywheel namespace.
	 */
	public static class_2960 readFlywheelDefault(StringReader reader) throws CommandSyntaxException {
		int i = reader.getCursor();

		while (reader.canRead() && class_2960.method_12831(reader.peek())) {
		   reader.skip();
		}

		String s = reader.getString().substring(i, reader.getCursor());

		try {
		   return parseFlywheelDefault(s);
		} catch (class_151 resourcelocationexception) {
		   reader.setCursor(i);
		   throw ERROR_INVALID.createWithContext(reader);
		}
	}

	/**
	 * Same as {@link class_2960#method_36181()}, but also removes the file extension.
	 */
	public static String toDebugFileNameNoExtension(class_2960 resourceLocation) {
		var stringLoc = resourceLocation.method_36181();
		return stringLoc.substring(0, stringLoc.lastIndexOf('.'));
	}
}
