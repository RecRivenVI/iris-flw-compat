package dev.engine_room.flywheel.lib.model.baked;

import java.util.function.BiFunction;
import net.minecraft.class_1087;
import net.minecraft.class_1920;
import net.minecraft.class_1921;
import net.minecraft.class_2338;
import net.minecraft.class_4587;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.Nullable;
import dev.engine_room.flywheel.api.material.Material;
import dev.engine_room.flywheel.lib.internal.FlwLibXplat;
import dev.engine_room.flywheel.lib.model.SimpleModel;

@ApiStatus.NonExtendable
public abstract class BakedModelBuilder {
	final class_1087 bakedModel;
	@Nullable
	class_1920 level;
	@Nullable
	class_2338 pos;
	@Nullable
	class_4587 poseStack;
	@Nullable
	BiFunction<class_1921, Boolean, Material> materialFunc;

	BakedModelBuilder(class_1087 bakedModel) {
		this.bakedModel = bakedModel;
	}

	public static BakedModelBuilder create(class_1087 bakedModel) {
		return FlwLibXplat.INSTANCE.createBakedModelBuilder(bakedModel);
	}

	public BakedModelBuilder level(@Nullable class_1920 level) {
		this.level = level;
		return this;
	}

	public BakedModelBuilder pos(@Nullable class_2338 pos) {
		this.pos = pos;
		return this;
	}

	public BakedModelBuilder poseStack(@Nullable class_4587 poseStack) {
		this.poseStack = poseStack;
		return this;
	}

	public BakedModelBuilder materialFunc(@Nullable BiFunction<class_1921, Boolean, Material> materialFunc) {
		this.materialFunc = materialFunc;
		return this;
	}

	public abstract SimpleModel build();
}
