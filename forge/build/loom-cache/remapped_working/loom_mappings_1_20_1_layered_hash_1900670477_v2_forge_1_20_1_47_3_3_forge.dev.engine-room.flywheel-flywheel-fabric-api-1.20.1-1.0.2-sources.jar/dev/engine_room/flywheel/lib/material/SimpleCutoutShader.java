package dev.engine_room.flywheel.lib.material;

import dev.engine_room.flywheel.api.material.CutoutShader;
import net.minecraft.class_2960;

public record SimpleCutoutShader(@Override class_2960 source) implements CutoutShader {
}
