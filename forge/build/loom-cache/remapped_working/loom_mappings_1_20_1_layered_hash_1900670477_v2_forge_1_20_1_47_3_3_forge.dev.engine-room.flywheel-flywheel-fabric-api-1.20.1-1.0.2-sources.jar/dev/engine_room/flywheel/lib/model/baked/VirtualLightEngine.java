package dev.engine_room.flywheel.lib.model.baked;

import java.util.function.ToIntFunction;
import net.minecraft.class_1922;
import net.minecraft.class_1923;
import net.minecraft.class_1944;
import net.minecraft.class_2338;
import net.minecraft.class_2804;
import net.minecraft.class_2823;
import net.minecraft.class_3562;
import net.minecraft.class_3568;
import net.minecraft.class_4076;
import net.minecraft.class_8527;
import org.jetbrains.annotations.Nullable;

public final class VirtualLightEngine extends class_3568 {
	private final class_3562 blockListener;
	private final class_3562 skyListener;

	public VirtualLightEngine(ToIntFunction<class_2338> blockLightFunc, ToIntFunction<class_2338> skyLightFunc, class_1922 level) {
		super(new class_2823() {
					@Override
					@Nullable
					public class_8527 method_12246(int x, int z) {
						return null;
					}

					@Override
					public class_1922 method_16399() {
						return level;
					}
				}, false, false);

		blockListener = new VirtualLayerLightEventListener(blockLightFunc);
		skyListener = new VirtualLayerLightEventListener(skyLightFunc);
	}

	@Override
	public class_3562 method_15562(class_1944 layer) {
		return layer == class_1944.field_9282 ? blockListener : skyListener;
	}

	@Override
	public int method_22363(class_2338 pos, int amount) {
		int i = skyListener.method_15543(pos) - amount;
		int j = blockListener.method_15543(pos);
		return Math.max(j, i);
	}

	private static class VirtualLayerLightEventListener implements class_3562 {
		private final ToIntFunction<class_2338> lightFunc;

		public VirtualLayerLightEventListener(ToIntFunction<class_2338> lightFunc) {
			this.lightFunc = lightFunc;
		}

		@Override
		public void method_15513(class_2338 pos) {
		}

		@Override
		public boolean method_15518() {
			return false;
		}

		@Override
		public int method_15516() {
			return 0;
		}

		@Override
		public void method_15551(class_4076 pos, boolean isSectionEmpty) {
		}

		@Override
		public void method_15512(class_1923 pos, boolean lightEnabled) {
		}

		@Override
		public void method_51471(class_1923 pos) {
		}

		@Override
		public class_2804 method_15544(class_4076 pos) {
			return null;
		}

		@Override
		public int method_15543(class_2338 pos) {
			return lightFunc.applyAsInt(pos);
		}
	}
}
