package dev.engine_room.flywheel.api.internal;

import org.jetbrains.annotations.Nullable;

import dev.engine_room.flywheel.api.backend.Backend;
import dev.engine_room.flywheel.api.layout.LayoutBuilder;
import dev.engine_room.flywheel.api.registry.IdRegistry;
import dev.engine_room.flywheel.api.visualization.BlockEntityVisualizer;
import dev.engine_room.flywheel.api.visualization.EntityVisualizer;
import dev.engine_room.flywheel.api.visualization.VisualizationManager;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1936;
import net.minecraft.class_2586;
import net.minecraft.class_2591;

public interface FlwApiLink {
	FlwApiLink INSTANCE = DependencyInjection.load(FlwApiLink.class, "dev.engine_room.flywheel.impl.FlwApiLinkImpl");

	<T> IdRegistry<T> createIdRegistry();

	Backend getCurrentBackend();

	boolean isBackendOn();

	Backend getOffBackend();

	Backend getDefaultBackend();

	LayoutBuilder createLayoutBuilder();

	boolean supportsVisualization(@Nullable class_1936 level);

	@Nullable
	VisualizationManager getVisualizationManager(@Nullable class_1936 level);

	VisualizationManager getVisualizationManagerOrThrow(@Nullable class_1936 level);

	@Nullable
	<T extends class_2586> BlockEntityVisualizer<? super T> getVisualizer(class_2591<T> type);

	@Nullable
	<T extends class_1297> EntityVisualizer<? super T> getVisualizer(class_1299<T> type);

	<T extends class_2586> void setVisualizer(class_2591<T> type, @Nullable BlockEntityVisualizer<? super T> visualizer);

	<T extends class_1297> void setVisualizer(class_1299<T> type, @Nullable EntityVisualizer<? super T> visualizer);
}
