package dev.engine_room.flywheel.api.visualization;

import net.minecraft.class_1936;

/**
 * A marker interface custom levels can override to indicate
 * that block entities and entities inside the level should
 * render with Flywheel.
 * <br>
 * {@link net.minecraft.class_310#field_1687 Minecraft#level} is special cased and will support Flywheel by default.
 */
public interface VisualizationLevel extends class_1936 {
	default boolean supportsVisualization() {
		return true;
	}
}
