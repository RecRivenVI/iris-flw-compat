package dev.engine_room.flywheel.lib.visual;

import dev.engine_room.flywheel.api.instance.InstancerProvider;
import dev.engine_room.flywheel.api.visual.Visual;
import dev.engine_room.flywheel.api.visualization.VisualizationContext;
import net.minecraft.class_1937;
import net.minecraft.class_2382;

public abstract class AbstractVisual implements Visual {
	/**
	 * The visualization context used to construct this visual.
	 * <br>
	 * Useful for passing to child visuals.
	 */
	protected final VisualizationContext visualizationContext;
	protected final class_1937 level;

	protected boolean deleted = false;

	public AbstractVisual(VisualizationContext ctx, class_1937 level, float partialTick) {
		this.visualizationContext = ctx;
		this.level = level;
	}

	@Override
	public void update(float partialTick) {
	}

    protected abstract void _delete();

	protected InstancerProvider instancerProvider() {
		return visualizationContext.instancerProvider();
	}

	protected class_2382 renderOrigin() {
		return visualizationContext.renderOrigin();
	}

	@Override
	public final void delete() {
		if (deleted) {
			return;
		}

		_delete();
		deleted = true;
	}
}
