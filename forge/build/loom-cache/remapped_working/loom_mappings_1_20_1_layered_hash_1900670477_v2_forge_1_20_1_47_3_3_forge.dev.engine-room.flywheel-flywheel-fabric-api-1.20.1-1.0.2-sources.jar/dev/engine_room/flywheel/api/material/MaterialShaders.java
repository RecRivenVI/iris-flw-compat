package dev.engine_room.flywheel.api.material;

import net.minecraft.class_2960;

/**
 * A vertex and fragment shader pair that can be attached to a material.
 */
public interface MaterialShaders {
	/**
	 * @apiNote {@code flywheel/} is implicitly prepended to the {@link class_2960}'s path.
	 */
	class_2960 vertexSource();

	/**
	 * @apiNote {@code flywheel/} is implicitly prepended to the {@link class_2960}'s path.
	 */
	class_2960 fragmentSource();
}
