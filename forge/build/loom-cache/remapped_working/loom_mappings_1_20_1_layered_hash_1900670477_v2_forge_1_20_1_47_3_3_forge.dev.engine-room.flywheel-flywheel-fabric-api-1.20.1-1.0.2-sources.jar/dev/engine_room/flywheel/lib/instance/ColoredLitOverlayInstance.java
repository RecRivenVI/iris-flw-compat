package dev.engine_room.flywheel.lib.instance;

import dev.engine_room.flywheel.api.instance.InstanceHandle;
import dev.engine_room.flywheel.api.instance.InstanceType;
import net.minecraft.class_4608;

public abstract class ColoredLitOverlayInstance extends ColoredLitInstance {
	public int overlay = class_4608.field_21444;

	public ColoredLitOverlayInstance(InstanceType<? extends ColoredLitOverlayInstance> type, InstanceHandle handle) {
		super(type, handle);
	}

	public ColoredLitOverlayInstance overlay(int overlay) {
		this.overlay = overlay;
		return this;
	}
}
