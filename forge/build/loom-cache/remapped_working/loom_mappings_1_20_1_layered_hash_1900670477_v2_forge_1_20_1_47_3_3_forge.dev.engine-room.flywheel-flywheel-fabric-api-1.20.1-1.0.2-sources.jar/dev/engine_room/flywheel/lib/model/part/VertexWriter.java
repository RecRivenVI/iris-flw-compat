package dev.engine_room.flywheel.lib.model.part;

import org.lwjgl.system.MemoryUtil;
import dev.engine_room.flywheel.lib.math.DataPacker;
import dev.engine_room.flywheel.lib.memory.MemoryBlock;
import dev.engine_room.flywheel.lib.vertex.PosTexNormalVertexView;
import net.minecraft.class_4588;

class VertexWriter implements class_4588 {
	private static final int STRIDE = (int) PosTexNormalVertexView.STRIDE;

	private MemoryBlock data;

	private int vertexCount;
	private boolean filledPosition;
	private boolean filledTexture;
	private boolean filledNormal;

	public VertexWriter() {
		data = MemoryBlock.malloc(128 * STRIDE);
	}

	@Override
	public class_4588 method_22912(double x, double y, double z) {
		if (!filledPosition) {
			long ptr = vertexPtr();
			MemoryUtil.memPutFloat(ptr, (float) x);
			MemoryUtil.memPutFloat(ptr + 4, (float) y);
			MemoryUtil.memPutFloat(ptr + 8, (float) z);
			filledPosition = true;
		}
		return this;
	}

	@Override
	public class_4588 method_1336(int red, int green, int blue, int alpha) {
		// ignore color
		return this;
	}

	@Override
	public class_4588 method_22913(float u, float v) {
		if (!filledTexture) {
			long ptr = vertexPtr();
			MemoryUtil.memPutFloat(ptr + 12, u);
			MemoryUtil.memPutFloat(ptr + 16, v);
			filledTexture = true;
		}
		return this;
	}

	@Override
	public class_4588 method_22917(int u, int v) {
		// ignore overlay
		return this;
	}

	@Override
	public class_4588 method_22921(int u, int v) {
		// ignore light
		return this;
	}

	@Override
	public class_4588 method_22914(float x, float y, float z) {
		if (!filledNormal) {
			long ptr = vertexPtr();
			MemoryUtil.memPutByte(ptr + 20, DataPacker.packNormI8(x));
			MemoryUtil.memPutByte(ptr + 21, DataPacker.packNormI8(y));
			MemoryUtil.memPutByte(ptr + 22, DataPacker.packNormI8(z));
			filledNormal = true;
		}
		return this;
	}

	@Override
	public void method_1344() {
		if (!filledPosition || !filledTexture || !filledNormal) {
			throw new IllegalStateException("Not filled all elements of the vertex");
		}

		filledPosition = false;
		filledTexture = false;
		filledNormal = false;
		vertexCount++;

		long byteSize = (vertexCount + 1) * STRIDE;
		long capacity = data.size();
		if (byteSize > capacity) {
			data = data.realloc(capacity * 2);
		}
	}

	@Override
	public void method_22901(int red, int green, int blue, int alpha) {
	}

	@Override
	public void method_35666() {
	}

	private long vertexPtr() {
		return data.ptr() + vertexCount * STRIDE;
	}

	public MemoryBlock copyDataAndReset() {
		MemoryBlock dataCopy = MemoryBlock.mallocTracked(vertexCount * STRIDE);
		data.copyTo(dataCopy);

		vertexCount = 0;
		filledPosition = false;
		filledTexture = false;
		filledNormal = false;

		return dataCopy;
	}
}
