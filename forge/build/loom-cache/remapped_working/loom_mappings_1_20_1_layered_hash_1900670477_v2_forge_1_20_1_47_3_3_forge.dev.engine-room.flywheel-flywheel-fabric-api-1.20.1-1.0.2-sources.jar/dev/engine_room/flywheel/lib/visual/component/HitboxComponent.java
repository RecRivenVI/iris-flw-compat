package dev.engine_room.flywheel.lib.visual.component;

import org.joml.Quaternionf;
import D;
import F;
import Z;
import dev.engine_room.flywheel.api.model.Model;
import dev.engine_room.flywheel.api.visual.DynamicVisual;
import dev.engine_room.flywheel.api.visualization.VisualizationContext;
import dev.engine_room.flywheel.lib.instance.InstanceTypes;
import dev.engine_room.flywheel.lib.instance.TransformedInstance;
import dev.engine_room.flywheel.lib.model.LineModelBuilder;
import dev.engine_room.flywheel.lib.visual.util.SmartRecycler;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_765;

public final class HitboxComponent implements EntityComponent {
	//    010------110
	//    /|       /|
	//   / |      / |
	// 011------111 |
	//  |  |     |  |
	//  | 000----|-100
	//  | /      | /
	//  |/       |/
	// 001------101
	public static final Model BOX_MODEL = new LineModelBuilder(12)
			// Starting from 0, 0, 0
			.line(0, 0, 0, 0, 0, 1)
			.line(0, 0, 0, 0, 1, 0)
			.line(0, 0, 0, 1, 0, 0)
			// Starting from 0, 1, 1
			.line(0, 1, 1, 0, 1, 0)
			.line(0, 1, 1, 0, 0, 1)
			.line(0, 1, 1, 1, 1, 1)
			// Starting from 1, 0, 1
			.line(1, 0, 1, 1, 0, 0)
			.line(1, 0, 1, 1, 1, 1)
			.line(1, 0, 1, 0, 0, 1)
			// Starting from 1, 1, 0
			.line(1, 1, 0, 1, 1, 1)
			.line(1, 1, 0, 1, 0, 0)
			.line(1, 1, 0, 0, 1, 0)
			.build();

	public static final Model LINE_MODEL = new LineModelBuilder(1)
			.line(0, 0, 0, 0, 2, 0)
			.build();

	private final VisualizationContext context;
	private final class_1297 entity;

	private final SmartRecycler<Model, TransformedInstance> recycler;

	private boolean showEyeBox;

	public HitboxComponent(VisualizationContext context, class_1297 entity) {
		this.context = context;
		this.entity = entity;
		this.showEyeBox = entity instanceof class_1309;

		this.recycler = new SmartRecycler<>(this::createInstance);
	}

	private TransformedInstance createInstance(Model model) {
		TransformedInstance instance = context.instancerProvider()
				.instancer(InstanceTypes.TRANSFORMED, model)
				.createInstance();
		instance.light(class_765.field_32769);
		instance.setChanged();
		return instance;
	}

	public boolean doesShowEyeBox() {
		return showEyeBox;
	}

	public HitboxComponent showEyeBox(boolean showEyeBox) {
		this.showEyeBox = showEyeBox;
		return this;
	}

	@Override
	public void beginFrame(DynamicVisual.Context context) {
		recycler.resetCount();

		var shouldRenderHitBoxes = class_310.method_1551()
				.method_1561()
				.method_3958();
		if (shouldRenderHitBoxes && !entity.method_5767() && !class_310.method_1551()
				.method_1555()) {
			double entityX = class_3532.method_16436(context.partialTick(), entity.field_6038, entity.method_23317());
			double entityY = class_3532.method_16436(context.partialTick(), entity.field_5971, entity.method_23318());
			double entityZ = class_3532.method_16436(context.partialTick(), entity.field_5989, entity.method_23321());

			var bbWidth = entity.method_17681();
			var bbHeight = entity.method_17682();
			var bbWidthHalf = bbWidth * 0.5;
			recycler.get(BOX_MODEL)
					.setIdentityTransform()
					.translate(entityX - bbWidthHalf, entityY, entityZ - bbWidthHalf)
					.scale(bbWidth, bbHeight, bbWidth)
					.setChanged();

			// TODO: multipart entities, but forge seems to have an
			//  injection for them so we'll need platform specific code.

			if (showEyeBox) {
				recycler.get(BOX_MODEL)
						.setIdentityTransform()
						.translate(entityX - bbWidthHalf, entityY + entity.method_5751() - 0.01, entityZ - bbWidthHalf)
						.scale(bbWidth, 0.02f, bbWidth)
						.color(255, 0, 0)
						.setChanged();
			}

			var viewVector = entity.method_5828(context.partialTick());

			recycler.get(LINE_MODEL)
					.setIdentityTransform()
					.translate(entityX, entityY + entity.method_5751(), entityZ)
					.rotate(new Quaternionf().rotateTo(0, 1, 0, (float) viewVector.field_1352, (float) viewVector.field_1351, (float) viewVector.field_1350))
					.color(0, 0, 255)
					.setChanged();
		}

		recycler.discardExtra();
	}

	@Override
	public void delete() {
		recycler.delete();
	}
}
