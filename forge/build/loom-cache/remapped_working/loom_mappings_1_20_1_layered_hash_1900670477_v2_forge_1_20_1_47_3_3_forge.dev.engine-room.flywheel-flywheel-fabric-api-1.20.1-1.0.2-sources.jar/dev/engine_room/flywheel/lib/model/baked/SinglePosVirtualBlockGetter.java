package dev.engine_room.flywheel.lib.model.baked;

import java.util.function.ToIntFunction;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import org.jetbrains.annotations.Nullable;

public class SinglePosVirtualBlockGetter extends VirtualBlockGetter {
	protected class_2338 pos = class_2338.field_10980;
	protected class_2680 blockState = class_2246.field_10124.method_9564();
	@Nullable
	protected class_2586 blockEntity;

	public SinglePosVirtualBlockGetter(ToIntFunction<class_2338> blockLightFunc, ToIntFunction<class_2338> skyLightFunc) {
		super(blockLightFunc, skyLightFunc);
	}

	public static SinglePosVirtualBlockGetter createFullDark() {
		return new SinglePosVirtualBlockGetter(p -> 0, p -> 0);
	}

	public static SinglePosVirtualBlockGetter createFullBright() {
		return new SinglePosVirtualBlockGetter(p -> 15, p -> 15);
	}

	public SinglePosVirtualBlockGetter pos(class_2338 pos) {
		this.pos = pos;
		return this;
	}

	public SinglePosVirtualBlockGetter blockState(class_2680 state) {
		blockState = state;
		return this;
	}

	public SinglePosVirtualBlockGetter blockEntity(@Nullable class_2586 blockEntity) {
		this.blockEntity = blockEntity;
		return this;
	}

	@Override
	@Nullable
	public class_2586 method_8321(class_2338 pos) {
		if (pos.equals(this.pos)) {
			return blockEntity;
		}

		return null;
	}

	@Override
	public class_2680 method_8320(class_2338 pos) {
		if (pos.equals(this.pos)) {
			return blockState;
		}

		return class_2246.field_10124.method_9564();
	}

	@Override
	public int method_31605() {
		return 1;
	}

	@Override
	public int method_31607() {
		return pos.method_10264();
	}
}
