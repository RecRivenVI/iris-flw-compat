package dev.engine_room.flywheel.lib.model.baked;

import java.util.function.ToIntFunction;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_3610;
import net.minecraft.class_3612;
import org.jetbrains.annotations.Nullable;

public class EmptyVirtualBlockGetter extends VirtualBlockGetter {
	public static final EmptyVirtualBlockGetter FULL_DARK = new EmptyVirtualBlockGetter(p -> 0, p -> 0);
	public static final EmptyVirtualBlockGetter FULL_BRIGHT = new EmptyVirtualBlockGetter(p -> 15, p -> 15);

	public EmptyVirtualBlockGetter(ToIntFunction<class_2338> blockLightFunc, ToIntFunction<class_2338> skyLightFunc) {
		super(blockLightFunc, skyLightFunc);
	}

	@Override
	@Nullable
	public final class_2586 method_8321(class_2338 pos) {
		return null;
	}

	@Override
	public final class_2680 method_8320(class_2338 pos) {
		return class_2246.field_10124.method_9564();
	}

	@Override
	public final class_3610 method_8316(class_2338 pos) {
		return class_3612.field_15906.method_15785();
	}

	@Override
	public final int method_31605() {
		return 1;
	}

	@Override
	public final int method_31607() {
		return 0;
	}
}
