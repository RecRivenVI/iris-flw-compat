package dev.engine_room.flywheel.lib.model.baked;

import java.util.concurrent.ConcurrentMap;
import net.minecraft.class_1087;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import org.jetbrains.annotations.UnknownNullability;

import com.google.common.collect.MapMaker;

import dev.engine_room.flywheel.lib.internal.FlwLibXplat;

/**
 * A helper class for loading and accessing JSON models not directly used by any blocks or items.
 * <br>
 * Creating a PartialModel will make Minecraft automatically load the associated modelLocation.
 * <br>
 * Once Minecraft has finished baking all models, all PartialModels will have their bakedModel fields populated.
 */
public final class PartialModel {
	static final ConcurrentMap<class_2960, PartialModel> ALL = new MapMaker().weakValues().makeMap();
	static boolean populateOnInit = false;

	private final class_2960 modelLocation;
	@UnknownNullability
	class_1087 bakedModel;

	private PartialModel(class_2960 modelLocation) {
		this.modelLocation = modelLocation;

		if (populateOnInit) {
			bakedModel = FlwLibXplat.INSTANCE.getBakedModel(class_310.method_1551().method_1554(), modelLocation);
		}
	}

	public static PartialModel of(class_2960 modelLocation) {
		return ALL.computeIfAbsent(modelLocation, PartialModel::new);
	}

	@UnknownNullability
	public class_1087 get() {
		return bakedModel;
	}

	public class_2960 modelLocation() {
		return modelLocation;
	}
}
