package dev.engine_room.flywheel.lib.model;

import org.joml.Vector4fc;

import dev.engine_room.flywheel.api.model.IndexSequence;
import dev.engine_room.flywheel.api.model.Mesh;
import dev.engine_room.flywheel.api.vertex.MutableVertexList;
import dev.engine_room.flywheel.lib.vertex.VertexTransformations;
import net.minecraft.class_1058;

public record RetexturedMesh(Mesh mesh, class_1058 sprite) implements Mesh {
	@Override
	public int vertexCount() {
		return mesh.vertexCount();
	}

	@Override
	public void write(MutableVertexList vertexList) {
		mesh.write(vertexList);
		VertexTransformations.retexture(vertexList, sprite);
	}

	@Override
	public IndexSequence indexSequence() {
		return mesh.indexSequence();
	}

	@Override
	public int indexCount() {
		return mesh.indexCount();
	}

	@Override
	public Vector4fc boundingSphere() {
		return mesh.boundingSphere();
	}
}

