package dev.engine_room.flywheel.lib.material;

import dev.engine_room.flywheel.api.material.FogShader;
import net.minecraft.class_2960;

public record SimpleFogShader(@Override class_2960 source) implements FogShader {
}
