package dev.engine_room.flywheel.lib.model;

import java.util.List;
import java.util.function.BiConsumer;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_4587;
import dev.engine_room.flywheel.api.model.Model;
import dev.engine_room.flywheel.lib.model.baked.BakedModelBuilder;
import dev.engine_room.flywheel.lib.model.baked.BlockModelBuilder;
import dev.engine_room.flywheel.lib.model.baked.PartialModel;
import dev.engine_room.flywheel.lib.model.baked.SinglePosVirtualBlockGetter;
import dev.engine_room.flywheel.lib.transform.TransformStack;
import dev.engine_room.flywheel.lib.util.RendererReloadCache;

/**
 * A collection of methods for creating models from various sources.
 * <br>
 * All Models returned from this class are cached, so calling the same
 * method with the same parameters will return the same object.
 */
public final class Models {
	private static final RendererReloadCache<class_2680, Model> BLOCK_STATE = new RendererReloadCache<>(it -> BlockModelBuilder.create(SinglePosVirtualBlockGetter.createFullDark()
					.blockState(it), List.of(class_2338.field_10980))
			.build());
	private static final RendererReloadCache<PartialModel, Model> PARTIAL = new RendererReloadCache<>(it -> BakedModelBuilder.create(it.get())
			.build());
	private static final RendererReloadCache<TransformedPartial<?>, Model> TRANSFORMED_PARTIAL = new RendererReloadCache<>(TransformedPartial::create);

	private Models() {
	}

	/**
	 * Get a usable model for a given block state.
	 *
	 * @param state The block state you wish to render.
	 * @return A model corresponding to how the given block state would appear in the level.
	 */
	public static Model block(class_2680 state) {
		return BLOCK_STATE.get(state);
	}

	/**
	 * Get a usable model for a given partial model.
	 * @param partial The partial model you wish to render.
	 * @return A model built from the baked model the partial model represents.
	 */
	public static Model partial(PartialModel partial) {
		return PARTIAL.get(partial);
	}

	/**
	 * Get a usable model for a given partial model, transformed in some way.
	 * <br>
	 * In general, you should try to avoid captures in the transformer function,
	 * i.e. prefer static method references over lambdas.
	 *
	 * @param partial     The partial model you wish to render.
	 * @param key         A key that will be used to cache the transformed model.
	 * @param transformer A function that will transform the model in some way.
	 * @param <T>         The type of the key.
	 * @return A model built from the baked model the partial model represents, transformed by the given function.
	 */
	public static <T> Model partial(PartialModel partial, T key, BiConsumer<T, class_4587> transformer) {
		return TRANSFORMED_PARTIAL.get(new TransformedPartial<>(partial, key, transformer));
	}

	/**
	 * Get a usable model for a given partial model, transformed to face a given direction.
	 * <br>
	 * {@link class_2350#field_11043} is considered the default direction and the corresponding transform will be a no-op.
	 *
	 * @param partial The partial model you wish to render.
	 * @param dir The direction you wish the model to be rotated to.
	 * @return A model built from the baked model the partial model represents, transformed to face the given direction.
	 */
	public static Model partial(PartialModel partial, class_2350 dir) {
		return partial(partial, dir, Models::rotateAboutCenterToFace);
	}

	private static void rotateAboutCenterToFace(class_2350 facing, class_4587 stack) {
		TransformStack.of(stack)
				.center()
				.rotateToFace(facing.method_10153())
				.uncenter();
	}

	private record TransformedPartial<T>(PartialModel partial, T key, BiConsumer<T, class_4587> transformer) {
		private Model create() {
			var stack = new class_4587();
			transformer.accept(key, stack);
			return BakedModelBuilder.create(partial.get())
					.poseStack(stack)
					.build();
		}
	}
}
