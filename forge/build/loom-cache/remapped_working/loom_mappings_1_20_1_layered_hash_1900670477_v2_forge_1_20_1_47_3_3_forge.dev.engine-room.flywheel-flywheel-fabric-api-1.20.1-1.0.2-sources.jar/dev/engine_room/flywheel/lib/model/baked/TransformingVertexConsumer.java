package dev.engine_room.flywheel.lib.model.baked;

import org.jetbrains.annotations.UnknownNullability;
import org.joml.Matrix3f;
import org.joml.Matrix4f;
import dev.engine_room.flywheel.lib.math.MatrixMath;
import net.minecraft.class_4587;
import net.minecraft.class_4588;

class TransformingVertexConsumer implements class_4588 {
	@UnknownNullability
	private class_4588 delegate;
	@UnknownNullability
	private class_4587 poseStack;

	public void prepare(class_4588 delegate, class_4587 poseStack) {
		this.delegate = delegate;
		this.poseStack = poseStack;
	}

	public void clear() {
		delegate = null;
		poseStack = null;
	}

	@Override
	public class_4588 method_22912(double x, double y, double z) {
		Matrix4f matrix = poseStack.method_23760().method_23761();
		float fx = (float) x;
		float fy = (float) y;
		float fz = (float) z;
		delegate.method_22912(
				MatrixMath.transformPositionX(matrix, fx, fy, fz),
				MatrixMath.transformPositionY(matrix, fx, fy, fz),
				MatrixMath.transformPositionZ(matrix, fx, fy, fz));
		return this;
	}

	@Override
	public class_4588 method_1336(int red, int green, int blue, int alpha) {
		delegate.method_1336(red, green, blue, alpha);
		return this;
	}

	@Override
	public class_4588 method_22913(float u, float v) {
		delegate.method_22913(u, v);
		return this;
	}

	@Override
	public class_4588 method_22917(int u, int v) {
		delegate.method_22917(u, v);
		return this;
	}

	@Override
	public class_4588 method_22921(int u, int v) {
		delegate.method_22921(u, v);
		return this;
	}

	@Override
	public class_4588 method_22914(float x, float y, float z) {
		Matrix3f matrix = poseStack.method_23760().method_23762();
		float fx = (float) x;
		float fy = (float) y;
		float fz = (float) z;
		delegate.method_22914(
				MatrixMath.transformNormalX(matrix, fx, fy, fz),
				MatrixMath.transformNormalY(matrix, fx, fy, fz),
				MatrixMath.transformNormalZ(matrix, fx, fy, fz));
		return this;
	}

	@Override
	public void method_1344() {
		delegate.method_1344();
	}

	@Override
	public void method_22901(int red, int green, int blue, int alpha) {
		delegate.method_22901(red, green, blue, alpha);
	}

	@Override
	public void method_35666() {
		delegate.method_35666();
	}
}
