package dev.engine_room.flywheel.api.material;

import net.minecraft.class_2960;

/**
 * A shader that decides what colors should be discarded in the fragment shader.
 */
public interface CutoutShader {
	/**
	 * @apiNote {@code flywheel/} is implicitly prepended to the {@link class_2960}'s path.
	 */
	class_2960 source();
}
