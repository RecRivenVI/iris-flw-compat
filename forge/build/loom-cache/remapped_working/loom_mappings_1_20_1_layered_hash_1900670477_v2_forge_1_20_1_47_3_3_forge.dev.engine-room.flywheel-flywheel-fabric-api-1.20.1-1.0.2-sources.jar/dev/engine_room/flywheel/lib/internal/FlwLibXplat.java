package dev.engine_room.flywheel.lib.internal;

import org.jetbrains.annotations.UnknownNullability;

import dev.engine_room.flywheel.api.internal.DependencyInjection;
import dev.engine_room.flywheel.lib.model.baked.BakedModelBuilder;
import dev.engine_room.flywheel.lib.model.baked.BlockModelBuilder;
import net.minecraft.class_1087;
import net.minecraft.class_1092;
import net.minecraft.class_1920;
import net.minecraft.class_2338;
import net.minecraft.class_2960;

public interface FlwLibXplat {
	FlwLibXplat INSTANCE = DependencyInjection.load(FlwLibXplat.class, "dev.engine_room.flywheel.impl.FlwLibXplatImpl");

	@UnknownNullability
	class_1087 getBakedModel(class_1092 modelManager, class_2960 location);

	BakedModelBuilder createBakedModelBuilder(class_1087 bakedModel);

	BlockModelBuilder createBlockModelBuilder(class_1920 level, Iterable<class_2338> positions);
}
