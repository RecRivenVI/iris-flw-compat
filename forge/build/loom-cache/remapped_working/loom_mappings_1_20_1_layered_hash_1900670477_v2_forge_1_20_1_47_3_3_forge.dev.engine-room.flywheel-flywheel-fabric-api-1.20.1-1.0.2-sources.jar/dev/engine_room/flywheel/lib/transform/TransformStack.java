package dev.engine_room.flywheel.lib.transform;

import dev.engine_room.flywheel.lib.internal.FlwLibLink;
import net.minecraft.class_4587;

public interface TransformStack<Self extends TransformStack<Self>> extends Transform<Self> {
	static PoseTransformStack of(class_4587 stack) {
		return FlwLibLink.INSTANCE.getPoseTransformStackOf(stack);
	}

	Self pushPose();

	Self popPose();
}
