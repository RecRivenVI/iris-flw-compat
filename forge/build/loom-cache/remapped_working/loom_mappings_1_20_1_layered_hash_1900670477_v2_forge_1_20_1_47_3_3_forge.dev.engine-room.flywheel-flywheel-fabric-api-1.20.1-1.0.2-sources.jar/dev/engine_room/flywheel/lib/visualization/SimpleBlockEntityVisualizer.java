package dev.engine_room.flywheel.lib.visualization;

import java.util.Objects;
import java.util.function.Predicate;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_827;
import org.jetbrains.annotations.Nullable;

import dev.engine_room.flywheel.api.visual.BlockEntityVisual;
import dev.engine_room.flywheel.api.visualization.BlockEntityVisualizer;
import dev.engine_room.flywheel.api.visualization.VisualizationContext;
import dev.engine_room.flywheel.api.visualization.VisualizerRegistry;

public final class SimpleBlockEntityVisualizer<T extends class_2586> implements BlockEntityVisualizer<T> {
	private final Factory<T> visualFactory;
	private final Predicate<T> skipVanillaRender;

	public SimpleBlockEntityVisualizer(Factory<T> visualFactory, Predicate<T> skipVanillaRender) {
		this.visualFactory = visualFactory;
		this.skipVanillaRender = skipVanillaRender;
	}

	@Override
	public BlockEntityVisual<? super T> createVisual(VisualizationContext ctx, T blockEntity, float partialTick) {
		return visualFactory.create(ctx, blockEntity, partialTick);
	}

	@Override
	public boolean skipVanillaRender(T blockEntity) {
		return skipVanillaRender.test(blockEntity);
	}

	/**
	 * Get an object to configure the visualizer for the given block entity type.
	 *
	 * @param type The block entity type to configure.
	 * @param <T>  The type of the block entity.
	 * @return The configuration object.
	 */
	public static <T extends class_2586> Builder<T> builder(class_2591<T> type) {
		return new Builder<>(type);
	}

	@FunctionalInterface
	public interface Factory<T extends class_2586> {
		BlockEntityVisual<? super T> create(VisualizationContext ctx, T blockEntity, float partialTick);
	}

	/**
	 * An object to configure the visualizer for a block entity.
	 *
	 * @param <T> The type of the block entity.
	 */
	public static final class Builder<T extends class_2586> {
		private final class_2591<T> type;
		@Nullable
		private Factory<T> visualFactory;
		@Nullable
		private Predicate<T> skipVanillaRender;

		public Builder(class_2591<T> type) {
			this.type = type;
		}

		/**
		 * Sets the visual factory for the block entity.
		 *
		 * @param visualFactory The visual factory.
		 * @return {@code this}
		 */
		public Builder<T> factory(Factory<T> visualFactory) {
			this.visualFactory = visualFactory;
			return this;
		}

		/**
		 * Sets a predicate to determine whether to skip rendering with the vanilla {@link class_827}.
		 *
		 * @param skipVanillaRender The predicate.
		 * @return {@code this}
		 */
		public Builder<T> skipVanillaRender(Predicate<T> skipVanillaRender) {
			this.skipVanillaRender = skipVanillaRender;
			return this;
		}

		/**
		 * Sets a predicate to never skip rendering with the vanilla {@link class_827}.
		 *
		 * @return {@code this}
		 */
		public Builder<T> neverSkipVanillaRender() {
			this.skipVanillaRender = blockEntity -> false;
			return this;
		}

		/**
		 * Constructs the block entity visualizer and sets it for the block entity type.
		 *
		 * @return The block entity visualizer.
		 */
		public SimpleBlockEntityVisualizer<T> apply() {
			Objects.requireNonNull(visualFactory, "Visual factory cannot be null!");
			if (skipVanillaRender == null) {
				skipVanillaRender = blockEntity -> true;
			}

			SimpleBlockEntityVisualizer<T> visualizer = new SimpleBlockEntityVisualizer<>(visualFactory, skipVanillaRender);
			VisualizerRegistry.setVisualizer(type, visualizer);
			return visualizer;
		}
	}
}
