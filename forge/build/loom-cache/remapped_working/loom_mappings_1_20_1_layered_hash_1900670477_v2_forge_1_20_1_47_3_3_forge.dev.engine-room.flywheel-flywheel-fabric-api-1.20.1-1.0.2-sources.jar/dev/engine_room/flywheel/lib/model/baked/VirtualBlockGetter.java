package dev.engine_room.flywheel.lib.model.baked;

import java.util.function.ToIntFunction;
import net.minecraft.class_1920;
import net.minecraft.class_1959;
import net.minecraft.class_1972;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_310;
import net.minecraft.class_3568;
import net.minecraft.class_3610;
import net.minecraft.class_6539;
import net.minecraft.class_7924;

public abstract class VirtualBlockGetter implements class_1920 {
	protected final VirtualLightEngine lightEngine;

	public VirtualBlockGetter(ToIntFunction<class_2338> blockLightFunc, ToIntFunction<class_2338> skyLightFunc) {
		lightEngine = new VirtualLightEngine(blockLightFunc, skyLightFunc, this);
	}

	@Override
	public class_3610 method_8316(class_2338 pos) {
		return method_8320(pos).method_26227();
	}

	@Override
	public float method_24852(class_2350 direction, boolean shaded) {
		return 1f;
	}

	@Override
	public class_3568 method_22336() {
		return lightEngine;
	}

	@Override
	public int method_23752(class_2338 pos, class_6539 resolver) {
		class_1959 plainsBiome = class_310.method_1551().method_1562().method_29091().method_30530(class_7924.field_41236).method_31140(class_1972.field_9451);
		return resolver.getColor(plainsBiome, pos.method_10263(), pos.method_10260());
	}
}
