package dev.engine_room.flywheel.api.visual;

import net.minecraft.class_1297;

public interface EntityVisual<T extends class_1297> extends Visual {
}
