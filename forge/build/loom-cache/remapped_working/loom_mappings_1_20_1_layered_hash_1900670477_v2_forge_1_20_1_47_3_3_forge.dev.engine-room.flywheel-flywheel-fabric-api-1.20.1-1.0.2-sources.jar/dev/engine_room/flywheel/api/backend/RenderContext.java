package dev.engine_room.flywheel.api.backend;

import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4599;
import net.minecraft.class_638;
import net.minecraft.class_761;
import org.joml.Matrix4fc;

public interface RenderContext {
	class_761 renderer();

	class_638 level();

	class_4599 buffers();

	class_4587 stack();

	Matrix4fc projection();

	Matrix4fc viewProjection();

	class_4184 camera();

	float partialTick();
}
