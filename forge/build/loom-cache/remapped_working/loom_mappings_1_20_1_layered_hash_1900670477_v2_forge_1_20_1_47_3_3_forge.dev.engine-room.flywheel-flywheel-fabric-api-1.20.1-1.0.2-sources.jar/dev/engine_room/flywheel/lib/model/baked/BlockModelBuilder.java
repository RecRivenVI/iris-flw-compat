package dev.engine_room.flywheel.lib.model.baked;

import java.util.function.BiFunction;
import net.minecraft.class_1920;
import net.minecraft.class_1921;
import net.minecraft.class_2338;
import net.minecraft.class_4587;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.Nullable;
import dev.engine_room.flywheel.api.material.Material;
import dev.engine_room.flywheel.lib.internal.FlwLibXplat;
import dev.engine_room.flywheel.lib.model.SimpleModel;

@ApiStatus.NonExtendable
public abstract class BlockModelBuilder {
	final class_1920 level;
	final Iterable<class_2338> positions;
	@Nullable
	class_4587 poseStack;
	boolean renderFluids = false;
	@Nullable
	BiFunction<class_1921, Boolean, Material> materialFunc;

	BlockModelBuilder(class_1920 level, Iterable<class_2338> positions) {
		this.level = level;
		this.positions = positions;
	}

	public static BlockModelBuilder create(class_1920 level, Iterable<class_2338> positions) {
		return FlwLibXplat.INSTANCE.createBlockModelBuilder(level, positions);
	}

	public BlockModelBuilder poseStack(@Nullable class_4587 poseStack) {
		this.poseStack = poseStack;
		return this;
	}

	public BlockModelBuilder renderFluids(boolean renderFluids) {
		this.renderFluids = renderFluids;
		return this;
	}

	public BlockModelBuilder materialFunc(@Nullable BiFunction<class_1921, Boolean, Material> materialFunc) {
		this.materialFunc = materialFunc;
		return this;
	}

	public abstract SimpleModel build();
}
