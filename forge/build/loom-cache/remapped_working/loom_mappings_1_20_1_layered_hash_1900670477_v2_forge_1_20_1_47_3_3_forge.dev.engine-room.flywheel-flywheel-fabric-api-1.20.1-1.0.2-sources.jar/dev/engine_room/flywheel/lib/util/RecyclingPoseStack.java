package dev.engine_room.flywheel.lib.util;

import java.util.ArrayDeque;
import java.util.Deque;
import net.minecraft.class_4587;
import dev.engine_room.flywheel.lib.internal.FlwLibLink;

/**
 * A {@link class_4587} that recycles {@link class_4587.class_4665} objects.
 *
 * <p>Vanilla's {@link class_4587} can get quite expensive to use when each game object needs to
 * maintain their own stack. This class helps alleviate memory pressure by making Pose objects
 * long-lived. Note that this means that you <em>CANNOT</em> safely store a Pose object outside
 * the RecyclingPoseStack that created it.
 */
public class RecyclingPoseStack extends class_4587 {
	private final Deque<class_4665> recycleBin = new ArrayDeque<>();

	@Override
	public void method_22903() {
		if (recycleBin.isEmpty()) {
			super.method_22903();
		} else {
			var last = method_23760();
			var recycle = recycleBin.removeLast();
			recycle.method_23761()
					.set(last.method_23761());
			recycle.method_23762()
					.set(last.method_23762());
			FlwLibLink.INSTANCE.getPoseStack(this)
					.addLast(recycle);
		}
	}

	@Override
	public void method_22909() {
		recycleBin.addLast(FlwLibLink.INSTANCE.getPoseStack(this)
				.removeLast());
	}
}
