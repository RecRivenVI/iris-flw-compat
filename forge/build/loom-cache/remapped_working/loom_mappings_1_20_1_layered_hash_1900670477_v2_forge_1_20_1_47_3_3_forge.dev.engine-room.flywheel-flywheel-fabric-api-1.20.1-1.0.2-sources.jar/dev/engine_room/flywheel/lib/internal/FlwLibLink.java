package dev.engine_room.flywheel.lib.internal;

import java.util.Deque;
import java.util.Map;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_630;
import org.slf4j.Logger;
import dev.engine_room.flywheel.api.internal.DependencyInjection;
import dev.engine_room.flywheel.lib.transform.PoseTransformStack;

public interface FlwLibLink {
	FlwLibLink INSTANCE = DependencyInjection.load(FlwLibLink.class, "dev.engine_room.flywheel.impl.FlwLibLinkImpl");

	Logger getLogger();

	PoseTransformStack getPoseTransformStackOf(class_4587 stack);

	Map<String, class_630> getModelPartChildren(class_630 part);

	void compileModelPart(class_630 part, class_4587.class_4665 pose, class_4588 consumer, int light, int overlay, float red, float green, float blue, float alpha);

	Deque<class_4587.class_4665> getPoseStack(class_4587 stack);

	boolean isIrisLoaded();

	boolean isOptifineInstalled();

	boolean isShaderPackInUse();

	boolean isRenderingShadowPass();
}
