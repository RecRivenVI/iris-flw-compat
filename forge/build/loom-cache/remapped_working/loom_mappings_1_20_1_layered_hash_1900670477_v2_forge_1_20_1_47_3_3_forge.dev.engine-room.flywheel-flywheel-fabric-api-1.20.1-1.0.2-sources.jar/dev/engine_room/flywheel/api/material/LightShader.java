package dev.engine_room.flywheel.api.material;

import net.minecraft.class_2960;

/**
 * A shader that controls the GPU-based light on a material.
 */
public interface LightShader {
	/**
	 * @apiNote {@code flywheel/} is implicitly prepended to the {@link class_2960}'s path.
	 */
	class_2960 source();
}
